clear all
close all




fid=fopen('ZelH240');


i=1;



while(feof(fid)==0)

    fscanf(fid,'%i',1);
    hh=fscanf(fid,'%f',1);
NN(i)=fscanf(fid,'%i',1);
vd(i)=fscanf(fid,'%f',1);
As(i)=fscanf(fid,'%f',1);
Ig(i)=fscanf(fid,'%f',1);
As1(i)=fscanf(fid,'%f',1);
As2(i)=fscanf(fid,'%f',1);
Inf1(i)=fscanf(fid,'%f',1);
Inf2(i)=fscanf(fid,'%f',1);
Pr1(i)=fscanf(fid,'%f',1);
Pr2(i)=fscanf(fid,'%f',1);

i=i+1;
end

xx=0:0.00001:1;
Fx=xx./(1+exp(-hh.*(xx-0.5)))-(1-xx)./(1+exp(hh.*(xx-0.5)));
Gx=xx.*heaviside(xx-0.5)-(1-xx).*heaviside(0.5-xx);

subplot(5,2,1);plot(Ig,vd,'.')
xlabel('influence gap')
ylabel('vote skew')
title('h=0')

axis([-1.0 1.0 -0.5 0.5])

subplot(5,2,2);plot(xx,Fx)
xlabel('proportion of within party influencers')

axis([0.0 1.0 -1.0 1.0])

fclose(fid);



fid=fopen('ZelH241');


i=1;



while(feof(fid)==0)

    fscanf(fid,'%i',1);
    hh=fscanf(fid,'%f',1);
NN(i)=fscanf(fid,'%i',1);
vd(i)=fscanf(fid,'%f',1);
As(i)=fscanf(fid,'%f',1);
Ig(i)=fscanf(fid,'%f',1);
As1(i)=fscanf(fid,'%f',1);
As2(i)=fscanf(fid,'%f',1);
Inf1(i)=fscanf(fid,'%f',1);
Inf2(i)=fscanf(fid,'%f',1);
Pr1(i)=fscanf(fid,'%f',1);
Pr2(i)=fscanf(fid,'%f',1);

i=i+1;
end

xx=0:0.00001:1;
Fx=xx./(1+exp(-hh.*(xx-0.5)))-(1-xx)./(1+exp(hh.*(xx-0.5)));
Gx=xx.*heaviside(xx-0.5)-(1-xx).*heaviside(0.5-xx);

subplot(5,2,3);plot(Ig,vd,'.')
xlabel('influence gap')
ylabel('vote skew')
title('h=1')

axis([-1.0 1.0 -0.5 0.5])

subplot(5,2,4);plot(xx,Fx)
xlabel('proportion of within party influencers')

axis([0.0 1.0 -1.0 1.0])

fclose(fid);

fid=fopen('ZelH2410');


i=1;



while(feof(fid)==0)

    fscanf(fid,'%i',1);
    hh=fscanf(fid,'%f',1);
NN(i)=fscanf(fid,'%i',1);
vd(i)=fscanf(fid,'%f',1);
As(i)=fscanf(fid,'%f',1);
Ig(i)=fscanf(fid,'%f',1);
As1(i)=fscanf(fid,'%f',1);
As2(i)=fscanf(fid,'%f',1);
Inf1(i)=fscanf(fid,'%f',1);
Inf2(i)=fscanf(fid,'%f',1);
Pr1(i)=fscanf(fid,'%f',1);
Pr2(i)=fscanf(fid,'%f',1);

i=i+1;
end

xx=0:0.00001:1;
Fx=xx./(1+exp(-hh.*(xx-0.5)))-(1-xx)./(1+exp(hh.*(xx-0.5)));
Gx=xx.*heaviside(xx-0.5)-(1-xx).*heaviside(0.5-xx);

subplot(5,2,5);plot(Ig,vd,'.')
xlabel('influence gap')
ylabel('vote skew')
title('h=10')

axis([-1.0 1.0 -0.5 0.5])

subplot(5,2,6);plot(xx,Fx)
xlabel('proportion of within party influencers')

axis([0.0 1.0 -1.0 1.0])

fclose(fid);


fid=fopen('ZelH24100');


i=1;



while(feof(fid)==0)

    fscanf(fid,'%i',1);
    hh=fscanf(fid,'%f',1);
NN(i)=fscanf(fid,'%i',1);
vd(i)=fscanf(fid,'%f',1);
As(i)=fscanf(fid,'%f',1);
Ig(i)=fscanf(fid,'%f',1);
As1(i)=fscanf(fid,'%f',1);
As2(i)=fscanf(fid,'%f',1);
Inf1(i)=fscanf(fid,'%f',1);
Inf2(i)=fscanf(fid,'%f',1);
Pr1(i)=fscanf(fid,'%f',1);
Pr2(i)=fscanf(fid,'%f',1);

i=i+1;
end

xx=0:0.00001:1;
Fx=xx./(1+exp(-hh.*(xx-0.5)))-(1-xx)./(1+exp(hh.*(xx-0.5)));
Gx=xx.*heaviside(xx-0.5)-(1-xx).*heaviside(0.5-xx);

subplot(5,2,7);plot(Ig,vd,'.')
xlabel('influence gap')
ylabel('vote skew')
title('h=100')

axis([-1.0 1.0 -0.5 0.5])

subplot(5,2,8);plot(xx,Fx)
xlabel('proportion of within party influencers')

axis([0.0 1.0 -1.0 1.0])

fclose(fid);

fid=fopen('ZelH24Inf');


i=1;



while(feof(fid)==0)

    fscanf(fid,'%i',1);
    hh=fscanf(fid,'%f',1);
NN(i)=fscanf(fid,'%i',1);
vd(i)=fscanf(fid,'%f',1);
As(i)=fscanf(fid,'%f',1);
Ig(i)=fscanf(fid,'%f',1);
As1(i)=fscanf(fid,'%f',1);
As2(i)=fscanf(fid,'%f',1);
Inf1(i)=fscanf(fid,'%f',1);
Inf2(i)=fscanf(fid,'%f',1);
Pr1(i)=fscanf(fid,'%f',1);
Pr2(i)=fscanf(fid,'%f',1);

i=i+1;
end

xx=0:0.00001:1;
Fx=xx./(1+exp(-hh.*(xx-0.5)))-(1-xx)./(1+exp(hh.*(xx-0.5)));
Gx=xx.*heaviside(xx-0.5)-(1-xx).*heaviside(0.5-xx);

subplot(5,2,9);plot(Ig,vd,'.')
xlabel('influence gap')
ylabel('vote skew')
title('h->infty')

axis([-1.0 1.0 -0.5 0.5])

subplot(5,2,10);plot(xx,Gx)
xlabel('proportion of within party influencers')

axis([0.0 1.0 -1.0 1.0])