clear all
close all

% load data for zealot evolution sims (with fixed susceptible strategy)
% v1 and v2 are time series proportion of zealots on each team
% vA average total number of zealots at each time
% p1 and p2 are time series susceptible strategy (fixed in this case)
% pA is average susceptible startegy at each time step
% nz is a 2x2 grid giving the proportion of runs who had a given proportion
% of zealots oneach team at the end of the simualtions (used to produce
% Figure S8b)

load 'FigureS8_Mesh'

figure(1)

subplot(1,2,2);mesh(0:1/12:1,0:1/12:1,nz)


% load data for zealot evolution sims (with evolving susceptible strategy)
% v1B and v2B are time series proportion of zealots on each team
% vAB average total number of zealots at each time
% p1B and p2B are time series susceptible strategy 
% pAB is average susceptible startegy at each time step (used to produce
% Figure S8a)
% nzB is a 2x2 grid giving the proportion of runs who had a given proportion
% of zealots oneach team at the end of the simualtions 



load 'FigureS8_SusEvo'

subplot(1,2,1);plot(1:250,pAB(1:250)./length(p1B(:,1)))