clear all
close all

fid=fopen('ZelNashNull');


i=1;

ep=1e-3;

N=24;

hv=zeros(1,N+1);

while(feof(fid)==0)
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
vv(i)=fscanf(fid,'%f',1);
ii=floor(N*vv(i)+ep)+1;
hv(ii)=hv(ii)+1;


wy(i)=fscanf(fid,'%f',1);
wp(i)=fscanf(fid,'%f',1);
i=i+1;
end

subplot(1,3,1);bar(0:1/24:1,hv./(sum(hv)))
xlabel('vote share (yellow)')
ylabel('frequency')
axis([0 1 0.0 0.8])

fid=fopen('ZelNashAssort');


i=1;

ep=1e-3;

N=24;

hv=zeros(1,N+1);
clear vv

while(feof(fid)==0)
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
vv(i)=fscanf(fid,'%f',1);
ii=floor(N*vv(i)+ep)+1;
hv(ii)=hv(ii)+1;
wy(i)=fscanf(fid,'%f',1);
wp(i)=fscanf(fid,'%f',1);
i=i+1;
end

subplot(1,3,2);bar(0:1/24:1,hv./sum(hv))
xlabel('vote share (yellow)')
ylabel('frequency')
axis([0 1 0.0 0.8])



fid=fopen('ZelNashAsym');


i=1;

ep=1e-3;

N=24;

hv=zeros(1,N+1);
clear vv

while(feof(fid)==0)
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
vv(i)=fscanf(fid,'%f',1);
ii=floor(N*vv(i)+ep)+1;
hv(ii)=hv(ii)+1;
wy(i)=fscanf(fid,'%f',1);
wp(i)=fscanf(fid,'%f',1);
i=i+1;
end

subplot(1,3,3);bar(1:-1/24:0,hv./sum(hv))
xlabel('vote share (preffered)')
ylabel('frequency')
axis([0 1 0.0 0.8])