#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <cfloat>
#include <vector>
#include <cstdio>
#include "mtrand.h"


using namespace std;



unsigned long MTRand_int32::state[n] = {0x0UL};
int MTRand_int32::p = 0;
bool MTRand_int32::init = false;

void MTRand_int32::gen_state() { // generate new state vector
    for (int i = 0; i < (n - m); ++i)
        state[i] = state[i + m] ^ twiddle(state[i], state[i + 1]);
    for (int i = n - m; i < (n - 1); ++i)
        state[i] = state[i + m - n] ^ twiddle(state[i], state[i + 1]);
    state[n - 1] = state[m - 1] ^ twiddle(state[n - 1], state[0]);
    p = 0; // reset position
}

void MTRand_int32::seed(unsigned long s) {  // init by 32 bit seed
    state[0] = s & 0xFFFFFFFFUL; // for > 32 bit machines
    for (int i = 1; i < n; ++i) {
        state[i] = 1812433253UL * (state[i - 1] ^ (state[i - 1] >> 30)) + i;
        // see Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier
        // in the previous versions, MSBs of the seed affect only MSBs of the array state
        // 2002/01/09 modified by Makoto Matsumoto
        state[i] &= 0xFFFFFFFFUL; // for > 32 bit machines
    }
    p = n; // force gen_state() to be called for next random number
}



#define N 100
#define G 1000
#define E 25000
#define Er 100
#define p 0.01
#define mp 0.5
#define Tim 241
#define Tth 83
#define T0 1
#define V 0.6
#define Nmax 100
#define E0 0.0
#define E1 0.0

int N2;

double ppw[11];
double qqw[11];
double ppm[11];
double qqm[11];

double ppw2[11];
double qqw2[11];
double ppm2[11];
double qqm2[11];

double pw[Nmax];
double pm[Nmax];
double qm[Nmax];
double qw[Nmax];


double pw2[Nmax];
double pm2[Nmax];
double qm2[Nmax];
double qw2[Nmax];

int Deg[N];

int Te[Nmax];
int Vote[Nmax];
int ZZ[Nmax];
int Zy;
int Zp;
int Inf1;
int Inf2;

//ofstream fout("ThreshGrEvo2_c100_10");

MTRand_int32 irand((unsigned)time(NULL)); // 32-bit int generator
MTRand drand;

double factorial (double a)
{
    if (a > 1)
        return (a * factorial (a-1));
    else
        return (1);
}

double nchoosek (double NN, double kk)
{
    if (kk > 0)
        return ((NN/kk) * nchoosek(NN-1, kk-1));
    else
        return (1);
}

vector <int> Init(N,0);
vector < vector <int> > MM(N,Init);



int main(void)
{
    cout<<mp<<'\t'<<p<<'\t'<<N<<'\t'<<N2<<'\n';
    
    int ii;
    int jj;
    int kk;
    int cnti;
    int cnto;
    int cntop1;
    int cntop2;
    int cntop3=0;
    int cntop4=0;
    int Di[N+1];
    int Do[N+1];
    int cnt1;
    int cnt2;
    double wp1;
    double wp2;
    double Cl1[N];
    double Cl2[N];
    double Clav1;
    double Clav2;
    
    
    for(int i=0;i<N;i++)
    {
        Do[i]=0;
        Di[i]=0;
    }
    
    for(int ee=0;ee<E;ee++)
    {
        //SET SIZE OF PARTIES:
        N2=50;//+irand()%31;
        
        //SET NUMBER OF ZEALOTS TO BE RANDOMLY PLACED
        
        Zy=0;//irand()%(11);
        Zp=0;//irand()%(11);
        
        //RANDOMLY CONNECT PLAYERS TO MEMBERS OF THEIR OWN PARTY WITH PROBABILITY P
        
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                MM[i][j]=0;
                
                if(i>=N2 && j>=N2)
                {
                    if(drand()<p && i!=j)
                    {
                        MM[i][j]=1;
                    }
                }
                else if(i<N2 && j<N2)
                {
                    if(drand()<p && i!=j)
                    {
                        MM[i][j]=1;
                    }
                }
            }
            
        }
        
        //GENERATE LONG TAILED DEGREE DISTRIBUTIONS USING PREFERENTIAL ATTACHMENT VIA DUPLICATION PLUS RANDOM ADDING OF CROSS PARTY EDGES
        
        for(int g=0;g<G;g++)
        {
            
            
            
            
            
            ii=irand()%N;
            jj=irand()%N;
            
            
            if(ii>=N2)
            {
                while(jj<N2)
                {
                    jj=irand()%N;
                }
            }
            else
            {
                while(jj>=N2)
                {
                    jj=irand()%N;
                }
                
            }
            
            
            
            
            
            for(int i=0;i<N;i++)
            {
                MM[jj][i]=0;
                MM[i][jj]=0;
                
            }
            
            
            
            for(int j=0;j<N;j++)
            {
                MM[jj][j]=MM[ii][j];
                MM[j][jj]=MM[j][ii];
                
            }
            
            MM[jj][jj]=0;
            
            
            
            ii=irand()%N;
            jj=irand()%N;
            
            if(ii>=N2)
            {
                while(jj<N2)
                {
                    jj=irand()%N;
                }
            }
            else
            {
                while(jj>=N2)
                {
                    jj=irand()%N;
                }
                
            }
            
            
            
            
            
            for(int i=0;i<N;i++)
            {
                MM[jj][i]=0;
                MM[i][jj]=0;
                
            }
            
            
            
            for(int j=0;j<N;j++)
            {
                MM[jj][j]=MM[ii][j];
                MM[j][jj]=MM[j][ii];
                
            }
            
            MM[jj][jj]=0;
            
            if(drand()<mp)
            {
                
                
                ii=irand()%N;
                jj=irand()%N;
                
                while(ii==jj)
                {
                    jj=irand()%N;
                }
                
                MM[ii][jj]=1;
                
            }
            
            
            
            
            
            
            
            //ENSURE ALL NODES HAVE INCOMING AND OUTGOING EDGES
        }
        
        for(int i=0;i<N;i++)
        {
            
            cnti=0;
            cnto=0;
            for(int j=0;j<N;j++)
            {
                if(MM[i][j]==1)
                {
                    cnti=cnti+1;
                }
                
                if(MM[j][i]==1)
                {
                    cnto=cnto+1;
                }
                
            }
            
            if(cnti==0)
            {
                kk=irand()%N;
                if(i>=N2)
                {
                    
                    while(kk==i || kk<N2)
                    {
                        kk=irand()%N;
                    }
                    MM[i][kk]=1;
                }
                
                if(i<N2)
                {
                    
                    while(kk==i || kk>=N2)
                    {
                        kk=irand()%N;
                    }
                    MM[i][kk]=1;
                }
            }
            
            if(cnto==0)
            {
                
                kk=irand()%N;
                if(i>=N2)
                {
                    
                    while(kk==i || kk<N2)
                    {
                        kk=irand()%N;
                    }
                    MM[kk][i]=1;
                }
                
                if(i<N2)
                {
                    
                    while(kk==i || kk>=N2)
                    {
                        kk=irand()%N;
                    }
                    MM[kk][i]=1;
                }
                
            }
            
        }
        
        
        //CALCULATE NETWORK STATISTICS
        
        wp1=0.0;
        wp2=0.0;
        cnt1=0;
        cnt2=0;
        Clav1=0.0;
        Clav2=0.0;
        cntop3=0;
        cntop4=0;
        
        for(int i=0;i<N;i++)
        {
            cnti=0;
            cnto=0;
            cntop1=0;
            cntop2=0;
            Cl1[i]=0;
            Cl2[i]=0;
            
            for(int j=0;j<N;j++)
            {
                if(MM[i][j]==1)
                {
                    cnti=cnti+1;
                }
                
                if(MM[j][i]==1)
                {
                    cnto=cnto+1;
                }
                
                if(MM[j][i]==1 && j<N2 && i>=N2)
                {
                    cntop1=cntop1+1;
                }
                if(MM[j][i]==1 && j>=N2 && i<N2)
                {
                    cntop2=cntop2+1;
                }
                
                
                if(MM[i][j]==1 && i<N2)
                {
                    cntop3=cntop3+1;
                }
                if(MM[i][j]==1 && i>=N2)
                {
                    cntop4=cntop4+1;
                }
                
                if(MM[j][i]==1)
                {
                    for(int k=0;k<N;k++)
                    {
                        if(MM[k][j]==1 && MM[k][i]==1)
                        {
                            if(i<N2)
                            {
                                
                                Cl1[i]=Cl1[i]+1.0;
                                
                            }
                            
                            if(i>=N2)
                            {
                                
                                Cl2[i]=Cl2[i]+1.0;
                                
                            }
                            
                            
                            
                        }
                        
                    }
                    
                }
                
                
            }
            
            
            
            
            
            
            
            
            if(cnto>1 && i<N2)
            {
                Cl1[i]=Cl1[i]/double(cnto*(cnto-1));
            }
            
            if(cnto>1 && i>=N2)
            {
                Cl2[i]=Cl2[i]/double(cnto*(cnto-1));
            }
            
            Clav1=Clav1+Cl1[i]/double(N2);
            Clav2=Clav2+Cl2[i]/double(N-N2);
            Di[cnti]=Di[cnti]+1;
            Do[cnto]=Do[cnto]+1;
            
            
            
            if(cnto>0 && cntop1<0.5*cnto && i>=N2)
            {
                wp1=wp1+(cnto-cntop1)/(cnto);
            }
            else if(cnto>0 && cntop1>0.5*cnto && i>=N2)
            {
                wp1=wp1-(cntop1)/(cnto);
            }
            
            if(cnto>0 && cntop2<0.5*cnto && i<N2)
            {
                wp2=wp2+(cnto-cntop2)/(cnto);
            }
            else if(cnto>0 && cntop2>0.5*cnto && i<N2)
            {
                wp2=wp2-(cntop2)/(cnto);
            }
            
            if(cnto>0 && i>=N2)
            {
                cnt1=cnt1+1;
            }
            
            if(cnto>0 && i<N2)
            {
                cnt2=cnt2+1;
            }
            
            Deg[i]=cnto;
            
            if(MM[i][i]==1)
            {
                cout<<"Hat"<<'\n';
                exit(1);
            }
            
            
            
        }
        
        //SIMULATE BEHAVIORAL MODEL ON THE RESULTING NETWORK
        
        
        
        ppw[0]=   0.0169;
        ppw[1]=   0.00;
        ppw[2]=   0.00;
        ppw[3]=   0.00;
        ppw[4]=   0.0028;
        ppw[5]=   0.00;
        ppw[6]=   0.0085;
        ppw[7]=   0.0056;
        ppw[8]=   0.00;
        ppw[9]=   0.0169;
        ppw[10]=  0.9493;
        
        qqm[0]=   0.00;
        qqm[1]=   0.0042;
        qqm[2]=   0.0021;
        qqm[3]=   0.0042;
        qqm[4]=   0.0042;
        qqm[5]=   0.0104;
        qqm[6]=   0.0125;
        qqm[7]=   0.0125;
        qqm[8]=   0.0375;
        qqm[9]=   0.0354;
        qqm[10]=  0.8771;
        
        qqw[0]=   0.2098;
        qqw[1]=   0.0747;
        qqw[2]=   0.046;
        qqw[3]=   0.0402;
        qqw[4]=   0.0172;
        qqw[5]=   0.0345;
        qqw[6]=   0.0259;
        qqw[7]=   0.0287;
        qqw[8]=   0.0402;
        qqw[9]=   0.0575;
        qqw[10]=  0.4253;
        
        
        
        ppw2[0]=   0.0092;
        ppw2[1]=   0.0031;
        ppw2[2]=   0.00;
        ppw2[3]=   0.0031;
        ppw2[4]=   0.00;
        ppw2[5]=   0.0031;
        ppw2[6]=   0.0061;
        ppw2[7]=   0.00;
        ppw2[8]=   0.0092;
        ppw2[9]=   0.0123;
        ppw2[10]=  0.954;
        
        qqm2[0]=   0.055;
        qqm2[1]=   0.0048;
        qqm2[2]=   0.0096;
        qqm2[3]=   0.0024;
        qqm2[4]=   0.0096;
        qqm2[5]=   0.0048;
        qqm2[6]=   0.0048;
        qqm2[7]=   0.0144;
        qqm2[8]=   0.0191;
        qqm2[9]=   0.0263;
        qqm2[10]=  0.8493;
        
        qqw2[0]=   0.2822;
        qqw2[1]=   0.0644;
        qqw2[2]=   0.0153;
        qqw2[3]=   0.0215;
        qqw2[4]=   0.0337;
        qqw2[5]=   0.0031;
        qqw2[6]=   0.0337;
        qqw2[7]=   0.0429;
        qqw2[8]=   0.0307;
        qqw2[9]=   0.0429;
        qqw2[10]=  0.4294;
        
        double rr;
        double sumr;
        int ii1;
        int ii2;
        int jj1;
        int jj2;
        int jj;
        double mv;
        int Vcp=0;
        int Vcy=0;
        double dv=0.0;
        
        for(int er=0;er<Er;er++)
        {
            mv=0.0;
            
            
            for(int i=0;i<N;i++)
            {
                ZZ[i]=0;
                MM[i][i]=1;
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+ppw[jj-1];
                }
                pw[i]=0.1*(jj-1);
                
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqm[jj-1];
                }
                qm[i]=0.1*(jj-1);
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqw[jj-1];
                }
                qw[i]=0.1*(jj-1);
                
                
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+ppw2[jj-1];
                }
                pw2[i]=0.1*(jj-1);
                
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqm2[jj-1];
                }
                qm2[i]=0.1*(jj-1);
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqw2[jj-1];
                }
                qw2[i]=0.1*(jj-1);
                
                
                
                
                if(i<N2)
                {
                    
                    
                    //tecnt=tecnt+1;
                    
                    Te[i]=0;
                    Vote[i]=0;
                    
                    
                    
                }
                else
                {
                    Te[i]=1;
                    Vote[i]=1;
                    
                    
                }
                
            }
            
            for(int i=0;i<Zy;i++)
            {
                ZZ[i]=1;
            }
            
            for(int i=0;i<Zp;i++)
            {
                ZZ[N/2+i]=1;
            }
            
            for(int tt=0;tt<Tim;tt++)
            {
                
                
                
                if(tt<Tth)
                {
                    
                    for(int i=0;i<N;i++)
                    {
                        
                        jj=irand()%N;
                        sumr=0.0;
                        ii1=0;
                        ii2=0;
                        for(int j=0;j<N;j++)
                        {
                            if(MM[j][jj]==1)
                            {
                                if(Te[jj]==1)
                                {
                                    sumr=sumr+(Vote[j]+E1)/double(Deg[jj]+1+E1+E0);
                                }
                                else
                                {
                                    sumr=sumr+(abs(1-Vote[j])+E0)/double(Deg[jj]+1+E0+E1);
                                }
                                ii1=ii1+1;//Vote[j];
                                
                            }
                            if(MM[jj][j]==1)
                            {
                                
                                ii2=ii2+1;//Vote[j];
                                
                            }
                            
                        }
                        
                        if(ii1!=Deg[jj]+1)
                        {
                            cout<<jj<<'\t'<<i<<'\t'<<ii1<<'\t'<<ii2<<'\t'<<Deg[jj]+1<<'\n';
                            for(int j=0;j<N;j++)
                            {
                                cout<<j<<'\t'<<MM[j][jj]<<'\n';
                            }
                            exit(0);
                        }
                        
                        
                        
                        if(sumr>=V)
                        {
                            
                            if(drand()<pw[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else if(sumr>1.0-V)
                        {
                            //cout<<sumr<<'\n';
                            if(drand()<qm[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else
                        {
                            if(drand()<qw[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        //cout<<abs(Te[jj]-1)<<'\n';
                        
                        
                        
                        
                        
                    }
                    
                }
                else
                {
                    // int tecnt=0;
                    for(int i=0;i<N;i++)
                    {
                        
                        jj=irand()%N;
                        sumr=0.0;
                        ii1=0;
                        ii2=0;
                        for(int j=0;j<N;j++)
                        {
                            if(MM[j][jj]==1)
                            {
                                if(Te[jj]==1)
                                {
                                    sumr=sumr+(Vote[j]+E1)/double(Deg[jj]+1+E1+E0);
                                }
                                else
                                {
                                    sumr=sumr+(abs(1-Vote[j])+E0)/double(Deg[jj]+1+E0+E1);
                                }
                                
                                ii1=ii1+1;//Vote[j];
                                
                            }
                            if(MM[jj][j]==1)
                            {
                                
                                ii2=ii2+1;//Vote[j];
                                
                            }
                            
                        }
                        
                        if(ii1!=Deg[jj]+1)
                        {
                            cout<<jj<<'\t'<<i<<'\t'<<ii1<<'\t'<<ii2<<'\n';
                            exit(0);
                        }
                        
                        
                        
                        if(sumr>=V)
                        {
                            
                            if(drand()<pw2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else if(sumr>1.0-V)
                        {
                            //cout<<sumr<<'\n';
                            if(drand()<qm2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else
                        {
                            if(drand()<qw2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        //cout<<abs(Te[jj]-1)<<'\n';
                        
                        
                        
                        
                    }
                    // cout<<tecnt/double(N)<<'\n';
                }
                
                
                
                
                
                /* for(int i=0;i<N;i++)
                 {
                 cout<<tt<<'\t'<<i<<'\t'<<Vote[i]<<'\n';
                 }*/
                
                
                
                if(tt==Tim-1)
                {
                    
                    for(int i=0;i<N;i++)
                    {
                        mv=mv+Vote[i]/double(T0*N);
                    }
                    
                    if(mv>=V)
                    {
                        Vcp=Vcp+1;
                        
                    }
                    
                    if(1.0-mv>=V)
                    {
                        Vcy=Vcy+1;
                        
                    }
                    
                    
                    
                    dv=dv+2.0*mv-1.0;
                    
                    
                    mv=0.0;
                    
                    
                }
                
            }
            
        }
        
        
        wp1=0.0;
        wp2=0.0;
        cnt1=0;
        cnt2=0;
        Clav1=0.0;
        Clav2=0.0;
        cntop3=0;
        cntop4=0;
        Inf1=0;
        Inf2=0;
        
        
        for(int i=0;i<N;i++)
        {
            cnti=0;
            cnto=E0+E1;
            cntop1=E1;
            cntop2=E0;
            Cl1[i]=0;
            Cl2[i]=0;
            
            for(int j=0;j<N;j++)
            {
                if(MM[i][j]==1)
                {
                    cnti=cnti+1;
                }
                
                if(MM[j][i]==1)
                {
                    cnto=cnto+1;
                }
                
                if(MM[j][i]==1 && j<N2 && i>=N2)
                {
                    cntop1=cntop1+1;
                }
                if(MM[j][i]==1 && j>=N2 && i<N2)
                {
                    cntop2=cntop2+1;
                }
                
                
                if(MM[i][j]==1 && i<N2)
                {
                    cntop3=cntop3+1;
                }
                if(MM[i][j]==1 && i>=N2)
                {
                    cntop4=cntop4+1;
                }
                
                if(MM[j][i]==1)
                {
                    for(int k=0;k<N;k++)
                    {
                        if(MM[k][j]==1 && MM[k][i]==1)
                        {
                            if(i<N2)
                            {
                                
                                Cl1[i]=Cl1[i]+1.0;
                                
                            }
                            
                            if(i>=N2)
                            {
                                
                                Cl2[i]=Cl2[i]+1.0;
                                
                            }
                            
                            
                            
                        }
                        
                    }
                    
                }
                
                
            }
            
            
            
            
            
            
            
            
            if(cnto>1 && i<N2)
            {
                Cl1[i]=Cl1[i]/double(cnto*(cnto-1));
            }
            
            if(cnto>1 && i>=N2)
            {
                Cl2[i]=Cl2[i]/double(cnto*(cnto-1));
            }
            
            Clav1=Clav1+Cl1[i]/double(N2);
            Clav2=Clav2+Cl2[i]/double(N-N2);
            // Di[cnti]=Di[cnti]+1;
            // Do[cnto]=Do[cnto]+1;
            
            if(ZZ[i]>=0)
            {
                
                if(cnto>0 && cntop1<=0.5*cnto && i>=N2)
                {
                    wp1=wp1+(cnto-cntop1)/double(cnto);//-1.0/(1.0+exp(hh*((cnto-cntop1)/double(cnto)-0.5)));
                }
                else if(cnto>0 && cntop1>0.5*cnto && i>=N2)
                {
                    wp1=wp1+(cnto-cntop1)/double(cnto)-1.0;//-1.0/(1.0+exp(hh*((cnto-cntop1)/double(cnto)-0.5)));//-(cntop1)/(cnto);
                }
                
                if(cnto>0 && cntop2<=0.5*cnto && i<N2)
                {
                    wp2=wp2+(cnto-cntop2)/double(cnto);//-1.0/(1.0+exp(hh*((cnto-cntop2)/double(cnto)-0.5)));//+(cnto-cntop2)/(cnto);
                }
                else if(cnto>0 && cntop2>0.5*cnto && i<N2)
                {
                    wp2=wp2+(cnto-cntop2)/double(cnto)-1.0;//-1.0/(1.0+exp(hh*((cnto-cntop2)/double(cnto)-0.5)));;//-(cntop2)/(cnto);
                }
                
                if(cnto>0 && i>=N2)
                {
                    cnt1=cnt1+1;
                }
                
                if(cnto>0 && i<N2)
                {
                    cnt2=cnt2+1;
                }
                
                
                Deg[i]=cnto;
                
                if(i>=N2)
                {
                    Inf1=Inf1+cnti;
                }
                else
                {
                    Inf2=Inf2+cnti;
                }
                
            }
            
            
            
            
            
        }
        
        cout<<ee<<'\t'<<Zy<<'\t'<<Zp<<'\t'<<N2<<'\t'<<dv/double(Er)<<'\t'<<(wp1+wp2)/double(N)<<'\t'<<(wp1)/double(N-N2)-(wp2)/double(N2)<<'\t'<<(wp1)/double(N-N2)<<'\t'<<(wp2)/double(N2)<<'\t'<<Inf1/double(N*(N-N2))<<'\t'<<Inf2/double(N*N2)<<'\t'<<0.5*(1.0+dv/double(Er))/double(N-N2)<<'\t'<<0.5*(1.0-dv/double(Er))/double(N2)<<'\n';
    }
    
    for(int i=0;i<N;i++)
    {
        cout<<i<<'\t'<<Di[i]/double((E)*N)<<'\t'<<Do[i]/double((E)*N)<<'\n';
    }
    
    
    return 0;
}









