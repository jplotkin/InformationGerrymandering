#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <cfloat>
#include <vector>
#include <cstdio>
#include "mtrand.h"


using namespace std;



unsigned long MTRand_int32::state[n] = {0x0UL};
int MTRand_int32::p = 0;
bool MTRand_int32::init = false;

void MTRand_int32::gen_state() { // generate new state vector
    for (int i = 0; i < (n - m); ++i)
        state[i] = state[i + m] ^ twiddle(state[i], state[i + 1]);
    for (int i = n - m; i < (n - 1); ++i)
        state[i] = state[i + m - n] ^ twiddle(state[i], state[i + 1]);
    state[n - 1] = state[m - 1] ^ twiddle(state[n - 1], state[0]);
    p = 0; // reset position
}

void MTRand_int32::seed(unsigned long s) {  // init by 32 bit seed
    state[0] = s & 0xFFFFFFFFUL; // for > 32 bit machines
    for (int i = 1; i < n; ++i) {
        state[i] = 1812433253UL * (state[i - 1] ^ (state[i - 1] >> 30)) + i;
        // see Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier
        // in the previous versions, MSBs of the seed affect only MSBs of the array state
        // 2002/01/09 modified by Makoto Matsumoto
        state[i] &= 0xFFFFFFFFUL; // for > 32 bit machines
    }
    p = n; // force gen_state() to be called for next random number
}




#define G 2500
#define N 24
#define V 0.6
#define BB 4.0
#define Tim 1
#define R 100
#define E 10000
#define epsilon 0.01
#define delta 0.0001

double pW[N];
double pD[N];
double pL[N];
int Te[N];
int Mv[N];
double Sc[N];
double ScN[N];
double ScC[N];
double Vote;
int mut;
double pOW;
double pOD;
double pOL;
int NZ1;
int NZ2;
double pDav1;
double pLav1;
double pDav2;
double pLav2;
int Nw1;
int Nw2;
int flag;
int cnt;



MTRand_int32 irand((unsigned)time(NULL)); // 32-bit int generator
MTRand drand;

double factorial (double a)
{
    if (a > 1)
        return (a * factorial (a-1));
    else
        return (1);
}

double nchoosek (double NN, double kk)
{
    if (kk > 0)
        return ((NN/kk) * nchoosek(NN-1, kk-1));
    else
        return (1);
}





int main(void)
{
    for(int ee=0;ee<E;ee++)
    {
        
        NZ1=0;
        NZ2=0;
        pDav1=0.0;
        pLav1=0.0;
        pDav2=0.0;
        pLav2=0.0;
        
        for(int i=0;i<N;i++)
        {
            Sc[i]=0.0;
            ScN[i]=0.0;
            if(drand()<0.0)
            {
                pW[i]=1.0;
                pD[i]=1.0;
                pL[i]=1.0;
                if(i<N/2)
                {
                    NZ1=NZ1+1;
                }
                else
                {
                    NZ2=NZ2+1;
                }
                
            }
            else
            {
                pW[i]=1.0;
                pD[i]=0.5;//0.01*(irand()%101);
                pL[i]=0.0;//0.01*(irand()%101);
                
                if(pD[i]<=0.0)
                {
                    pD[i]=0.0+epsilon;
                }
                
                if(pD[i]>=1.0)
                {
                    pD[i]=1.0-epsilon;
                }
                
                
                if(i<N/2)
                {
                    pDav1=pDav1+pD[i];
                    pLav1=pLav1+pL[i];
                }
                else
                {
                    pDav2=pDav2+pD[i];
                    pLav2=pLav2+pL[i];
                }
            }
            
            if(i<N/2)
            {
                Te[i]=0;
                Mv[i]=0;
            }
            else
            {
                Te[i]=1;
                Mv[i]=1;
            }
            
        }
        
        pDav1=pDav1/double(N/2-NZ1);
        pLav1=pLav1/double(N/2-NZ1);
        pDav2=pDav2/double(N/2-NZ2);
        pLav2=pLav2/double(N/2-NZ2);
        
        
        for(int g=0;g<G;g++)
        {
            
            for(int i=0;i<N;i++)
            {
                ScC[i]=0.0;
            }
            
            Nw1=0;
            Nw2=0;
            
            for(int rr=0;rr<R;rr++)
            {
                
                Vote=0.0;
                for(int i=0;i<N;i++)
                {
                    
                    Mv[i]=Te[i];
                    Vote=Vote+Mv[i]/double(N);
                    
                }
                
                
                flag=0;
                cnt=0;
                
                while(flag==0)
                {
                    // cout<<t<<'\t'<<Vote<<'\n';
                    
                    for(int i=0;i<N;i++)
                    {
                        if(Te[i]==0)
                        {
                            if(Vote<=1.0-V)
                            {
                                if(drand()<=pW[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                            else if(Vote<V)
                            {
                                if(drand()<=pD[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                            else
                            {
                                if(drand()<=pL[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                        }
                        else
                        {
                            if(Vote<=1.0-V)
                            {
                                if(drand()<=pL[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                            else if(Vote<V)
                            {
                                if(drand()<=pD[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                            else
                            {
                                if(drand()<=pW[i])
                                {
                                    Mv[i]=Te[i];
                                }
                                else
                                {
                                    Mv[i]=abs(1-Te[i]);
                                }
                            }
                        }
                    }
                    
                    Vote=0.0;
                    for(int i=0;i<N;i++)
                    {
                        Vote=Vote+Mv[i]/double(N);
                    }
                    
                    if(Vote>=V || Vote<=1.0-V)
                    {
                        flag=1;
                    }
                    cnt=cnt+1;
                    
                    if(drand()<delta)
                    {
                        flag=1;
                    }
                    
                }
                
                
                for(int i=0;i<N;i++)
                {
                    
                    
                    if(Vote>=V && Te[i]==1)
                    {
                        ScC[i]=ScC[i]+BB/double(R);
                        Nw2=Nw2+1;
                    }
                    else if(Vote>=V && Te[i]==0)
                    {
                        ScC[i]=ScC[i]+1.0/double(R);
                    }
                    else if(Vote<=1.0-V && Te[i]==1)
                    {
                        ScC[i]=ScC[i]+1.0/double(R);
                    }
                    else if(Vote<=1.0-V && Te[i]==0)
                    {
                        ScC[i]=ScC[i]+BB/double(R);
                        Nw1=Nw1+1;
                    }
                    
                    
                }
                
                
                
                
                
                
            }
            
            for(int i=0;i<N;i++)
            {
                Sc[i]=ScN[i];
                ScN[i]=ScC[i];
            }
            
            if(g>0)
            {
                if(ScN[mut]<Sc[mut])
                {
                    pW[mut]=pOW;
                    pD[mut]=pOD;
                    pL[mut]=pOL;
                }
                else if(ScN[mut]==Sc[mut])
                {
                    if(drand()<0.99)
                    {
                        pW[mut]=pOW;
                        pD[mut]=pOD;
                        pL[mut]=pOL;
                    }
                }
            }
            
            
            
            NZ1=0;
            NZ2=0;
            pDav1=0.0;
            pLav1=0.0;
            pDav2=0.0;
            pLav2=0.0;
            
            int ttot=0.0;
            
            for(int i=0;i<N;i++)
            {
                
                if(pW[i]==1.0 && pD[i]==1.0 && pL[i]==1.0 && Te[i]==0)
                {
                    
                    NZ1=NZ1+1;
                    
                }
                else if(pW[i]==1.0 && pD[i]==1.0 && pL[i]==1.0 && Te[i]==1)
                {
                    
                    NZ2=NZ2+1;
                    
                }
                else if(Te[i]==0)
                {
                    
                    pDav1=pDav1+pD[i];
                    pLav1=pLav1+pL[i];
                }
                else
                {
                    
                    pDav2=pDav2+pD[i];
                    pLav2=pLav2+pL[i];
                }
                
                
                ttot=ttot+Te[i];
            }
            
            pDav1=pDav1/double(N/2-NZ1);
            pLav1=pLav1/double(N/2-NZ1);
            pDav2=pDav2/double(N/2-NZ2);
            pLav2=pLav2/double(N/2-NZ2);
            
            
            /* int ii=irand()%N;
             int jj=irand()%N;
             
             while(Te[ii]==Te[jj])
             {
             jj=irand()%N;
             }
             
             if(ScC[ii]<ScC[jj])
             {
             pW[ii]=pW[jj];
             pD[ii]=pD[jj];
             pL[ii]=pL[jj];
             }
             else if(ScC[ii]>ScC[jj])
             {
             pW[jj]=pW[ii];
             pD[jj]=pD[ii];
             pL[jj]=pL[ii];
             }*/
            
            
            mut=irand()%N;
            
            pOW=pW[mut];
            pOD=pD[mut];
            pOL=pL[mut];
            
            if(drand()<0.5)
            {
                pW[mut]=1.0;
                pD[mut]=1.0;
                pL[mut]=1.0;
                
            }
            else
            {
                pW[mut]=1.0;
                pD[mut]=0.01*(irand()%101);//pD[mut]+0.02*(irand()%2-0.5);
                pL[mut]=0.0;//0.01*(irand()%101);
                
                if(pD[mut]<=0.0)
                {
                    pD[mut]=0.0+epsilon;
                }
                
                if(pD[mut]>=1.0)
                {
                    pD[mut]=1.0-epsilon;
                }
                
                /*  if(pL[mut]<=0.0)
                 {
                 pL[mut]=0.0+epsilon;
                 }
                 
                 if(pL[mut]>=1.0)
                 {
                 pL[mut]=1.0-epsilon;
                 }*/
            }
            
            
            cout<<ee<<'\t'<<g<<'\t'<<2*Nw1/double(N*R)<<'\t'<<2*Nw2/double(N*R)<<'\t'<<2*NZ1/double(N)<<'\t'<<2*NZ2/double(N)<<'\t'<<pDav1<<'\t'<<pLav1<<'\t'<<pDav2<<'\t'<<pLav2<<'\t'<<ttot<<'\n';
        }
        
    }
    
    
    return 0;
}








