clear all
close all


%No assortment, no assymmetry

NNg(1,:)='a00-01_PSeries';
NNg(2,:)='a00-02_PSeries';
NNg(3,:)='a00-03_PSeries';
NNg(4,:)='a00-04_PSeries';
NNg(5,:)='a00-05_PSeries';
NNg(6,:)='a00-06_PSeries';
NNg(7,:)='a00-07_PSeries';
NNg(8,:)='a00-08_PSeries';
NNg(9,:)='a00-09_PSeries';
NNg(10,:)='a00-10_PSeries';
NNg(11,:)='a00-11_PSeries';
NNg(12,:)='a00-12_PSeries';
NNg(13,:)='a00-13_PSeries';
NNg(14,:)='a00-14_PSeries';
NNg(15,:)='a00-15_PSeries';
NNg(16,:)='a00-16_PSeries';
NNg(17,:)='a00-17_PSeries';
NNg(18,:)='a00-18_PSeries';
NNg(19,:)='a00-19_PSeries';
NNg(20,:)='a00-20_PSeries';

gg(1:20)=1;

%Assorted, no assymetry

NNg(21,:)='a01-01_PSeries';
NNg(22,:)='a01-02_PSeries';
NNg(23,:)='a01-03_PSeries';
NNg(24,:)='a01-04_PSeries';
NNg(25,:)='a01-05_PSeries';
NNg(26,:)='a01-06_PSeries';
NNg(27,:)='a01-07_PSeries';
NNg(28,:)='a01-08_PSeries';
NNg(29,:)='a01-09_PSeries';
NNg(30,:)='a01-10_PSeries';
NNg(31,:)='a01-11_PSeries';
NNg(32,:)='a01-12_PSeries';
NNg(33,:)='a01-13_PSeries';
NNg(34,:)='a01-14_PSeries';
NNg(35,:)='a01-15_PSeries';
NNg(36,:)='a01-16_PSeries';
NNg(37,:)='a01-17_PSeries';
NNg(38,:)='a01-18_PSeries';
NNg(39,:)='a01-19_PSeries';
NNg(40,:)='a01-20_PSeries';

gg(21:40)=2;

%Assorted, symmetrical zealot bots

NNg(41,:)='a04-01_PSeries';
NNg(42,:)='a04-02_PSeries';
NNg(43,:)='a04-03_PSeries';
NNg(44,:)='a04-04_PSeries';
NNg(45,:)='a04-05_PSeries';
NNg(46,:)='a04-06_PSeries';
NNg(47,:)='a04-07_PSeries';
NNg(48,:)='a04-08_PSeries';
NNg(49,:)='a04-09_PSeries';
NNg(50,:)='a04-10_PSeries';
NNg(51,:)='a04-11_PSeries';
NNg(52,:)='a04-12_PSeries';
NNg(53,:)='a04-13_PSeries';
NNg(54,:)='a04-14_PSeries';
NNg(55,:)='a04-15_PSeries';
NNg(56,:)='a04-16_PSeries';
NNg(57,:)='a04-17_PSeries';
NNg(58,:)='a04-18_PSeries';
NNg(59,:)='a04-19_PSeries';
NNg(60,:)='a04-20_PSeries';

gg(41:60)=3;

%Assorted, assymetry favoring Y

NNg(61,:)='a21-01_PSeries';
NNg(62,:)='a21-02_PSeries';
NNg(63,:)='a21-03_PSeries';
NNg(64,:)='a21-04_PSeries';
NNg(65,:)='a21-05_PSeries';
NNg(66,:)='a21-06_PSeries';
NNg(67,:)='a21-07_PSeries';
NNg(68,:)='a21-08_PSeries';
NNg(69,:)='a21-09_PSeries';
NNg(70,:)='a21-10_PSeries';

gg(61:70)=4;

%Assorted, assymetry favoring P

NNg(71,:)='a22-01_PSeries';
NNg(72,:)='a22-02_PSeries';
NNg(73,:)='a22-03_PSeries';
NNg(74,:)='a22-04_PSeries';
NNg(75,:)='a22-05_PSeries';
NNg(76,:)='a22-06_PSeries';
NNg(77,:)='a22-07_PSeries';
NNg(78,:)='a22-08_PSeries';
NNg(79,:)='a22-09_PSeries';
NNg(80,:)='a22-10_PSeries';


gg(71:80)=5;

%Assorted, bot placement favoring Y

NNg(81,:)='a31-01_PSeries';
NNg(82,:)='a31-02_PSeries';
NNg(83,:)='a31-03_PSeries';
NNg(84,:)='a31-04_PSeries';
NNg(85,:)='a31-05_PSeries';
NNg(86,:)='a31-06_PSeries';
NNg(87,:)='a31-07_PSeries';
NNg(88,:)='a31-08_PSeries';
NNg(89,:)='a31-09_PSeries';
NNg(90,:)='a31-10_PSeries';

gg(81:90)=6;

%Assorted, bot placement favoring P

NNg(91,:)='a32-01_PSeries';
NNg(92,:)='a32-02_PSeries';
NNg(93,:)='a32-03_PSeries';
NNg(94,:)='a32-04_PSeries';
NNg(95,:)='a32-05_PSeries';
NNg(96,:)='a32-06_PSeries';
NNg(97,:)='a32-07_PSeries';
NNg(98,:)='a32-08_PSeries';
NNg(99,:)='a32-09_PSeries';
NNg(100,:)='a32-10_PSeries';

gg(91:100)=7;



sr(1:100)=0.6; %supermajority theshold for each experiment



cnt=1;



for z=1:length(NNg(:,1))
    
   
load(NNg(z,:));

N=length(PW(:,1));


  
  PPR=zeros(N,240+1);
  VVR=zeros(N,240+1);

for i=1:N
    
    
    %EARLY GAME STRATEGIES

     Tim=83; %Time window end
     T0=0; %Time window start
    
    
        if VV(i,1)==0
            
        TeamR(i)='P';
        
        else
            
        TeamR(i)='Y';
        
        end
        

        TL(i)=length(find(TT(i,:)>0));
        
        if TT(i,1)==0.0
            
            TL(i)=TL(i)+1;
            
        end
        
      
        nTw(i)=0;
        nTm(i)=0;
        nOw(i)=0;
        nOm(i)=0;
        
        
        vTw(i)=0;
        vTm(i)=0;
        vOw(i)=0;
        vOm(i)=0;
       
        VT(i)=0;
  
            for j=2:TL(i)
                
              
                PPR(i,(TT(i,j-1))+1:(TT(i,j))+1)=PP(i,j-1)/(PP(i,j-1)+PY(i,j-1));%poll seen by player i at time TT
                VVR(i,(TT(i,j-1))+1:(TT(i,j))+1)=VV(i,j-1);% Vote of player i at time TT
                    
                
            end
            
                
                PPR(i,(TT(i,TL(i)))+1:(240+1))=PP(i,TL(i))/(PP(i,TL(i))+PY(i,TL(i)));
                VVR(i,(TT(i,TL(i)))+1:(240+1))=VV(i,TL(i));
            
          
        
        for tt=1:Tim
          
           
           
            
            
            if TeamR(i)=='P'
                
               
                
                VT(i)=VT(i)+1-VVR(i,tt);
                
                
                if PPR(i,tt)>sr(z)
                    
                    nTw(i)=nTw(i)+1;
                    
                   
                    
                    if VVR(i,tt)<0.5
                        
                        vTw(i)=vTw(i)+1;
                        
                    end
                    
            
                    
                elseif PPR(i,tt)>=1-sr(z)
                    
                    nOm(i)=nOm(i)+1;
                    
                    
                    if VVR(i,tt)<0.5
                        
                        vOm(i)=vOm(i)+1;
                        
                    end
                    
                    
                else
                    
                    
                    nOw(i)=nOw(i)+1;
                    
                   
                    
                    if VVR(i,tt)<0.5
                        
                        vOw(i)=vOw(i)+1;
                        
                    end
                    
                end
                 
                
            else
                
                
               
                
                
                if 1-PPR(i,tt)>sr(z)
                    
                    nTw(i)=nTw(i)+1;
                 
                    
                    if VVR(i,tt)==1
                        
                        vTw(i)=vTw(i)+1;
                        
                    end
                    
                    
                elseif 1-PPR(i,tt)>=1-sr(z)
                    
                    nOm(i)=nOm(i)+1;
                    
                    
                    
                    if VVR(i,tt)>0.5
                        
                        vOm(i)=vOm(i)+1;
                        
                    end
                    
                    
                else
                    
                    
                    nOw(i)=nOw(i)+1;
                    
                   
                    
                    if VVR(i,tt)>0.5
                        
                        vOw(i)=vOw(i)+1;
                        
                    end
                    
                end
            
                
            end
                       
        
            
        
        end
        
        
        
        
       %LATE GAME STRATEGIES

        Tim=240; %Time window end
        T0=84; %Time window start
      
        nTw2(i)=0;
        nTm2(i)=0;
        nOw2(i)=0;
        nOm2(i)=0;
        
        
        vTw2(i)=0;
        vTm2(i)=0;
        vOw2(i)=0;
        vOm2(i)=0;
     
          
        
        for tt=T0:Tim
          
           
            
            
            if TeamR(i)=='P'
                
               
                
                VT(i)=VT(i)+1-VVR(i,tt);
                
                
                if PPR(i,tt)>sr(z)
                    
                    nTw2(i)=nTw2(i)+1;
                    
                   
                    
                    if VVR(i,tt)<0.5
                        
                        vTw2(i)=vTw2(i)+1;
                        
                    end
                    
            
                    
                elseif PPR(i,tt)>=1-sr(z)
                    
                    nOm2(i)=nOm2(i)+1;
                    
                    
                    if VVR(i,tt)<0.5
                        
                        vOm2(i)=vOm2(i)+1;
                        
                    end
                    
                    
                else
                    
                    
                    nOw2(i)=nOw2(i)+1;
                    
                   
                    
                    if VVR(i,tt)<0.5
                        
                        vOw2(i)=vOw2(i)+1;
                        
                    end
                    
                end
                 
                
            else
                
                
                
                
                if 1-PPR(i,tt)>sr(z)
                    
                    nTw2(i)=nTw2(i)+1;
                 
                    
                    if VVR(i,tt)==1
                        
                        vTw2(i)=vTw2(i)+1;
                        
                    end
                    
                    
                elseif 1-PPR(i,tt)>=1-sr(z)
                    
                    nOm2(i)=nOm2(i)+1;
                    
                    
                    
                    if VVR(i,tt)>0.5
                        
                        vOm2(i)=vOm2(i)+1;
                        
                    end
                    
                    
                else
                    
                    
                    nOw2(i)=nOw2(i)+1;
                    
                   
                    
                    if VVR(i,tt)>0.5
                        
                        vOw2(i)=vOw2(i)+1;
                        
                    end
                    
                end
            
                
            end
           
       
           
        
        end
        
        
        
end
  

   
   
  
  
  for i=1:N
       
        ATT(cnt,1:TL(i))=TT(i,1:TL(i));
        AVV(cnt,1:TL(i))=1-VV(i,1:TL(i));
        APP(cnt,1:TL(i))=PP(i,1:TL(i))./(PP(i,1:TL(i))+PY(i,1:TL(i)));
        
        AVVR(cnt,1:Tim+1)=VVR(i,1:Tim+1);
        APPR(cnt,1:Tim+1)=PPR(i,1:Tim+1);
        
        
   gr(cnt)=gg(z);
  
   ATeam(cnt)=TeamR(i);
  
   AvTw(cnt)=vTw(i)/(nTw(i));
   AvTm(cnt)=vTm(i)/(nTm(i));
   AvOw(cnt)=vOw(i)/(nOw(i));
   AvOm(cnt)=vOm(i)/(nOm(i));
   
   AvTw2(cnt)=vTw2(i)/(nTw2(i));
   AvTm2(cnt)=vTm2(i)/(nTm2(i));
   AvOw2(cnt)=vOw2(i)/(nOw2(i));
   AvOm2(cnt)=vOm2(i)/(nOm2(i));
   
   
    
   cnt=cnt+1;    
   
   
   
   end
   
   
 

end

%Plot strategies for early phase

figure(1);
x=-0.05:0.1:1.05;
y=histc(AvTw(find(gr==1)),x);
yTw=y./sum(y);
subplot(3,2,1);bar(x+0.05,y./sum(y));
xlabel('p_{win,early}')
axis([-0.05 1.05 0 1])
y=histc(AvOm(find(gr==1)),x);
yOm=y./sum(y);
subplot(3,2,3);bar(x+0.05,y./sum(y))
xlabel('p_{deadlock,early}')
ylabel('frequency')
axis([-0.05 1.05 0 1])
y=histc(AvOw(find(gr==1)),x);
yOw=y./sum(y);
subplot(3,2,5);bar(x+0.05,y./sum(y))
xlabel('p_{lose,early}')
axis([-0.05 1.05 0 1])



%Plot strategies for late phase

x=-0.05:0.1:1.05;
y=histc(AvTw2(find(gr==1)),x);
yTw2=y./sum(y);
subplot(3,2,2);bar(x+0.05,y./sum(y));
xlabel('p_{win,late}')
axis([-0.05 1.05 0 1])
y=histc(AvOm2(find(gr==1)),x);
yOm2=y./sum(y);
subplot(3,2,4);bar(x+0.05,y./sum(y))
xlabel('p_{deadlock,late}')
axis([-0.05 1.05 0 1])
y=histc(AvOw2(find(gr==1)),x);
yOw2=y./sum(y);
subplot(3,2,6);bar(x+0.05,y./sum(y))
xlabel('p_{lose,late}')
axis([-0.05 1.05 0 1])


