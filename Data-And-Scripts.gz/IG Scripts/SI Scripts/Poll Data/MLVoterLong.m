clear all
close all


load 'S4PollDataAnal' %Processed time series data from all 5 experimental conditions

Rep=20; %Number of preplicates per condition
Exs=5; % Number of conditions
Tim=240; %Total experiment time (seconds)

Th=1:Tim-1; %Transition time parameter

LL=zeros(1,length(Th)); %LL will store the log likelihood for the data for each transition time. Note that experiment 1 data is used to perameterize the model

AVVR=1-AVVR;

for j=1:length(Th)
    
    i=0;
    jo=0;
    
z=1;%This specifies the experimental condition to look at. zz=1 corresponds to the numm (no assortment) condition used to perameterize the model
    
    
   for w=1:Rep
       
       jo=jo+1;
       
       sr(jo)=0.6;
       
       for io=1:AN(jo)
           
           i=i+1;
           
          
           for tt=1:Tim
               
               if ATeam(i)=='P'
                   
                   if APPR(i,tt)>=sr(jo) && tt<=Th(j)
                       
                       BB=length(find(APPR(i,1:Th(j))>=sr(jo))); % this is the total amount of time the player saw polling data with her preffered team winning before the threshold
                       AA=sum(AVVR(i,find(APPR(i,1:Th(j))>=sr(jo))));% this is the amount of time the player voted for her prffered team while the polling data showed her preffered team winning before the threshold
                       
                       %The ML estimate of the probability of voting for
                       %own party when the poll shows own party winning is
                       %thus AA/BB. The same goes for each of the other
                       %polling states (below)
                      
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
                   
                   if APPR(i,tt)<sr(jo) && APPR(i,tt)>=0.5 && tt<=Th(j)
                   
                       BB=length(find(APPR(i,1:Th(j))<sr(jo) & APPR(i,1:Th(j))>=0.5));
                       AA=sum(AVVR(i,find(APPR(i,1:Th(j))<sr(jo) & APPR(i,1:Th(j))>=0.5)));
                       
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                   
                 
               
                       
                   end
                   
                   
                   if APPR(i,tt)<0.5 && APPR(i,tt)>=1-sr(jo) && tt<=Th(j)
                   
                       BB=length(find(APPR(i,1:Th(j))>=1-sr(jo) & APPR(i,1:Th(j))<0.5));
                       AA=sum(AVVR(i,find(APPR(i,1:Th(j))>=1-sr(jo) & APPR(i,1:Th(j))<0.5)));
                       
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                  
                       
                   end
                   
                   if APPR(i,tt)<1-sr(jo) && tt<=Th(j)
                       
                       BB=length(find(APPR(i,1:Th(j))<1-sr(jo)));
                       AA=sum(AVVR(i,find(APPR(i,1:Th(j))<1-sr(jo))));
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
               elseif ATeam(i)=='Y'
                   
                   if 1-APPR(i,tt)>=sr(jo) && tt<=Th(j)
                       
                       
                   
                       BB=length(find(1-APPR(i,1:Th(j))>=sr(jo)));
                       AA=sum(1-AVVR(i,find(1-APPR(i,1:Th(j))>=sr(jo))));
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
                   
                   if 1-APPR(i,tt)<sr(jo) && 1-APPR(i,tt)>=0.5 && tt<=Th(j)
                   
                       BB=length(find(1-APPR(i,1:Th(j))<sr(jo) & 1-APPR(i,1:Th(j))>=0.5));
                       AA=sum(1-AVVR(i,find(1-APPR(i,1:Th(j))<sr(jo) & 1-APPR(i,1:Th(j))>=0.5)));
                      
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                   
                 
               
                       
                   end
                   
                   
                   if 1-APPR(i,tt)<0.5 && 1-APPR(i,tt)>=1-sr(jo) && tt<=Th(j)
                   
                       BB=length(find(1-APPR(i,1:Th(j))>=1-sr(jo) & 1-APPR(i,1:Th(j))<0.5));
                       AA=sum(1-AVVR(i,find(1-APPR(i,1:Th(j))>=1-sr(jo) & 1-APPR(i,1:Th(j))<0.5)));
                       
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                  
                       
                   end
                   
                   if 1-APPR(i,tt)<1-sr(jo) && tt<=Th(j)
                       
                       BB=length(find(1-APPR(i,1:Th(j))<1-sr(jo)));
                       AA=sum(1-AVVR(i,find(1-APPR(i,1:Th(j))<1-sr(jo))));
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
               end
                   
                   
                   
                   
                   
                   
               if ATeam(i)=='P'
                   
                   if APPR(i,tt)>=sr(jo) && tt>Th(j)
                       
                       BB=length(find(APPR(i,Th(j)+1:Tim)>=sr(jo)));
                       AA=sum(AVVR(i,find(APPR(i,Th(j)+1:Tim)>=sr(jo))+Th(j)));
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
                   
                   if APPR(i,tt)<sr(jo) && APPR(i,tt)>=0.5 && tt>Th(j)
                   
                       BB=length(find(APPR(i,Th(j)+1:Tim)<sr(jo) & APPR(i,Th(j)+1:Tim)>=0.5));
                       AA=sum(AVVR(i,find(APPR(i,Th(j)+1:Tim)<sr(jo) & APPR(i,Th(j)+1:Tim)>=0.5)+Th(j)));
                       
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                   
                 
               
                       
                   end
                   
                   
                   if APPR(i,tt)<0.5 && APPR(i,tt)>=1-sr(jo) && tt>Th(j)
                   
                       BB=length(find(APPR(i,Th(j)+1:Tim)>=1-sr(jo) & APPR(i,Th(j)+1:Tim)<0.5));
                       AA=sum(AVVR(i,find(APPR(i,Th(j)+1:Tim)>=1-sr(jo) & APPR(i,Th(j)+1:Tim)<0.5)+Th(j)));
                       
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                  
                       
                   end
                   
                   if APPR(i,tt)<1-sr(jo) && tt>Th(j)
                       
                       BB=length(find(APPR(i,Th(j)+1:Tim)<1-sr(jo)));
                       AA=sum(AVVR(i,find(APPR(i,Th(j)+1:Tim)<1-sr(jo))+Th(j)));
                       
                       if AVVR(i,tt)==1
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
               elseif ATeam(i)=='Y'
                   
                   if 1-APPR(i,tt)>=sr(jo) && tt>Th(j)
                       
                       
                   
                       BB=length(find(1-APPR(i,Th(j)+1:Tim)>=sr(jo)));
                       AA=sum(1-AVVR(i,find(1-APPR(i,Th(j)+1:Tim)>=sr(jo))+Th(j)));
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
                   
                   if 1-APPR(i,tt)<sr(jo) && 1-APPR(i,tt)>=0.5 && tt>Th(j)
                   
                       BB=length(find(1-APPR(i,Th(j)+1:Tim)<sr(jo) & 1-APPR(i,Th(j)+1:Tim)>=0.5));
                       AA=sum(1-AVVR(i,find(1-APPR(i,Th(j)+1:Tim)<sr(jo) & 1-APPR(i,Th(j)+1:Tim)>=0.5)+Th(j)));
                      
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                   
                 
               
                       
                   end
                   
                   
                   if 1-APPR(i,tt)<0.5 && 1-APPR(i,tt)>=1-sr(jo) && tt>Th(j)
                   
                       BB=length(find(1-APPR(i,Th(j)+1:Tim)>=1-sr(jo) & 1-APPR(i,Th(j)+1:Tim)<0.5));
                       AA=sum(1-AVVR(i,find(1-APPR(i,Th(j)+1:Tim)>=1-sr(jo) & 1-APPR(i,Th(j)+1:Tim)<0.5)+Th(j)));
                       
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                  
                       
                   end
                   
                   if 1-APPR(i,tt)<1-sr(jo) && tt>Th(j)
                       
                       BB=length(find(1-APPR(i,Th(j)+1:Tim)<1-sr(jo)));
                       AA=sum(1-AVVR(i,find(1-APPR(i,Th(j)+1:Tim)<1-sr(jo))+Th(j)));
                       
                       if AVVR(i,tt)==0
                   
                            LL(z,j)=LL(z,j)+log(AA/BB);
                   
                       else
                           
                            LL(z,j)=LL(z,j)+log(1-AA/BB);
                   
                       end
                       
                   end
                   
               end
               
               
               
           end
       end
               
   end
   

end
               
               

plot(Th,LL);
                   
