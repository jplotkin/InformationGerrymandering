#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <cfloat>
#include <vector>
#include <cstdio>
#include <sstream>
#include <string>
#include <math.h>
#include "mtrand.h"


using namespace std;



unsigned long MTRand_int32::state[nu] = {0x0UL};
int MTRand_int32::p = 0;
bool MTRand_int32::init = false;

void MTRand_int32::gen_state() { // generate new state vector
    for (int i = 0; i < (nu - m); ++i)
        state[i] = state[i + m] ^ twiddle(state[i], state[i + 1]);
    for (int i = nu - m; i < (nu - 1); ++i)
        state[i] = state[i + m - nu] ^ twiddle(state[i], state[i + 1]);
    state[nu - 1] = state[m - 1] ^ twiddle(state[nu - 1], state[0]);
    p = 0; // reset position
}

void MTRand_int32::seed(unsigned long s) {  // init by 32 bit seed
    state[0] = s & 0xFFFFFFFFUL; // for > 32 bit machines
    for (int i = 1; i < nu; ++i) {
        state[i] = 1812433253UL * (state[i - 1] ^ (state[i - 1] >> 30)) + i;
        // see Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier
        // in the previous versions, MSBs of the seed affect only MSBs of the array state
        // 2002/01/09 modified by Makoto Matsumoto
        state[i] &= 0xFFFFFFFFUL; // for > 32 bit machines
    }
    p = nu; // force gen_state() to be called for next random number
}



MTRand_int32 irand((unsigned)time(NULL)); // 32-bit int generator
MTRand drand;

#define R 10000
#define Tim 240
#define Tth 83
#define T0 1
#define V 0.6
#define Nmax 24
#define Cmax 2
#define Pmax 6
#define E 10000



//ofstream fout("BSSeries.txt");

double ppw[11];
double qqw[11];
double ppm[11];
double qqm[11];

double ppw2[11];
double qqw2[11];
double ppm2[11];
double qqm2[11];

double pw[Nmax];
double pm[Nmax];
double qm[Nmax];
double qw[Nmax];


double pw2[Nmax];
double pm2[Nmax];
double qm2[Nmax];
double qw2[Nmax];


int ZZ[Nmax];
int Te[Nmax];
int Ass[Nmax];
int Vote[Nmax];

int N;
int P;
int C=4;

vector <int> Init(Nmax,0);
vector < vector <int> > MM(Nmax,Init);

vector <int> Init2(Cmax,0);
vector < vector <int> > Cl(2,Init2);
vector < vector <int> > Zr(2,Init2);



float gammaln(float xx)
//Returns the value ln[Γ(xx)] for xx > 0.
{
    // Internal arithmetic will be done in double precision, a nicety that you can omit if five-figure
    //     accuracy is good enough.
    double x,y,tmp,ser;
    static double cof[6]={76.18009172947146,-86.50532032941677,
        24.01409824083091,-1.231739572450155,
        0.1208650973866179e-2,-0.5395239384953e-5};
    int j;
    y=x=xx;
    tmp=x+5.5;
    tmp -= (x+0.5)*log(tmp);
    ser=1.000000000190015;
    for (j=0;j<=5;j++) ser += cof[j]/++y;
    return -tmp+log(2.5066282746310005*ser/x);
}

int main(void)
{
    cout<<Nmax<<'\t'<<C<<'\t'<<R<<'\n';
    
    
    //inferred strategy distribution
    
     ppw[0]=   0.0169;
     ppw[1]=   0.00;
     ppw[2]=   0.00;
     ppw[3]=   0.00;
     ppw[4]=   0.0028;
     ppw[5]=   0.00;
     ppw[6]=   0.0085;
     ppw[7]=   0.0056;
     ppw[8]=   0.00;
     ppw[9]=   0.0169;
     ppw[10]=  0.9493;
    
     qqm[0]=   0.00;
     qqm[1]=   0.0042;
     qqm[2]=   0.0021;
     qqm[3]=   0.0042;
     qqm[4]=   0.0042;
     qqm[5]=   0.0104;
     qqm[6]=   0.0125;
     qqm[7]=   0.0125;
     qqm[8]=   0.0375;
     qqm[9]=   0.0354;
     qqm[10]=  0.8771;
    
     qqw[0]=   0.2098;
     qqw[1]=   0.0747;
     qqw[2]=   0.046;
     qqw[3]=   0.0402;
     qqw[4]=   0.0172;
     qqw[5]=   0.0345;
     qqw[6]=   0.0259;
     qqw[7]=   0.0287;
     qqw[8]=   0.0402;
     qqw[9]=   0.0575;
     qqw[10]=  0.4253;
     
     
     
     ppw2[0]=   0.0092;
     ppw2[1]=   0.0031;
     ppw2[2]=   0.00;
     ppw2[3]=   0.0031;
     ppw2[4]=   0.00;
     ppw2[5]=   0.0031;
     ppw2[6]=   0.0061;
     ppw2[7]=   0.00;
     ppw2[8]=   0.0092;
     ppw2[9]=   0.0123;
     ppw2[10]=  0.954;
    
     qqm2[0]=   0.055;
     qqm2[1]=   0.0048;
     qqm2[2]=   0.0096;
     qqm2[3]=   0.0024;
     qqm2[4]=   0.0096;
     qqm2[5]=   0.0048;
     qqm2[6]=   0.0048;
     qqm2[7]=   0.0144;
     qqm2[8]=   0.0191;
     qqm2[9]=   0.0263;
     qqm2[10]=  0.8493;
    
     qqw2[0]=   0.2822;
     qqw2[1]=   0.0644;
     qqw2[2]=   0.0153;
     qqw2[3]=   0.0215;
     qqw2[4]=   0.0337;
     qqw2[5]=   0.0031;
     qqw2[6]=   0.0337;
     qqw2[7]=   0.0429;
     qqw2[8]=   0.0307;
     qqw2[9]=   0.0429;
     qqw2[10]=  0.4294;
    
   
    
    
    
    double rr;
    double sumr;
    int ii1;
    int ii2;
    int jj1;
    int jj2;
    int jj;
    double mv;
    int Vcp=0;
    int Vcy=0;
    
    
        
        
        Vcp=0;
        Vcy=0;
        
        N=24;
        P=6;
        
        
        for(int ee=0;ee<E;ee++)
        {
          
            
            C=N/P;
            
            mv=0.0;
            
            
            
            
            //condition 1
            
            //creartes 4 ``districts'' for each condition
            
            Cl[0][0]=3;
            Cl[0][1]=3;
            Cl[0][2]=3;
            Cl[0][3]=3;
            
            
            Cl[1][0]=3;
            Cl[1][1]=3;
            Cl[1][2]=3;
            Cl[1][3]=3;
            
            //places zealots in each district
            
            Zr[0][0]=0;
            Zr[0][1]=0;
            Zr[0][2]=0;
            Zr[0][3]=0;
            
            
            Zr[1][0]=0;
            Zr[1][1]=0;
            Zr[1][2]=0;
            Zr[1][3]=0;

            /*
            //condition 2
            
            Cl[0][0]=5;
            Cl[0][1]=4;
            Cl[0][2]=2;
            Cl[0][3]=1;
            
            
            Cl[1][0]=1;
            Cl[1][1]=2;
            Cl[1][2]=4;
            Cl[1][3]=5;
            
            
            
            Zr[0][0]=0;
            Zr[0][1]=0;
            Zr[0][2]=0;
            Zr[0][3]=0;
            
            
            Zr[1][0]=0;
            Zr[1][1]=0;
            Zr[1][2]=0;
            Zr[1][3]=0;

            
            //condition 3
            
            Cl[0][0]=6;
            Cl[0][1]=2;
            Cl[0][2]=2;
            Cl[0][3]=2;
            
            
            Cl[1][0]=0;
            Cl[1][1]=4;
            Cl[1][2]=4;
            Cl[1][3]=4;
            
            
            
            Zr[0][0]=0;
            Zr[0][1]=0;
            Zr[0][2]=0;
            Zr[0][3]=0;
            
            
            Zr[1][0]=0;
            Zr[1][1]=0;
            Zr[1][2]=0;
            Zr[1][3]=0;

            
            //condition 4
            
            Cl[0][0]=5;
            Cl[0][1]=4;
            Cl[0][2]=2;
            Cl[0][3]=1;
            
            
            Cl[1][0]=1;
            Cl[1][1]=2;
            Cl[1][2]=4;
            Cl[1][3]=5;
            
            
            
            Zr[0][0]=0;
            Zr[0][1]=0;
            Zr[0][2]=2;
            Zr[0][3]=1;
            
            
            Zr[1][0]=1;
            Zr[1][1]=2;
            Zr[1][2]=0;
            Zr[1][3]=0;

            
            
            //condition 5
            
            Cl[0][0]=5;
            Cl[0][1]=4;
            Cl[0][2]=2;
            Cl[0][3]=1;
            
            
            Cl[1][0]=1;
            Cl[1][1]=2;
            Cl[1][2]=4;
            Cl[1][3]=5;
            
            
            
            Zr[0][0]=0;
            Zr[0][1]=0;
            Zr[0][2]=2;
            Zr[0][3]=1;
            
            
            Zr[1][0]=0;
            Zr[1][1]=0;
            Zr[1][2]=0;
            Zr[1][3]=3;
            */
            
            
            
            for(int i=0;i<N;i++)
            {
                //draws strategies for each player
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+ppw[jj-1];
                }
                pw[i]=0.1*(jj-1);
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqm[jj-1];
                }
                qm[i]=0.1*(jj-1);
                
                
                rr=drand();
                jj=0;
                sumr=0.0;
                while(rr>sumr)
                {
                    jj=jj+1;
                    sumr=sumr+qqw[jj-1];
                }
                qw[i]=0.1*(jj-1);
                
               
                    
                    
                    rr=drand();
                    jj=0;
                    sumr=0.0;
                    while(rr>sumr)
                    {
                        jj=jj+1;
                        sumr=sumr+ppw2[jj-1];
                    }
                    pw2[i]=0.1*(jj-1);
                
                    
                    rr=drand();
                    jj=0;
                    sumr=0.0;
                    while(rr>sumr)
                    {
                        jj=jj+1;
                        sumr=sumr+qqm2[jj-1];
                    }
                    qm2[i]=0.1*(jj-1);
                    
                    
                    rr=drand();
                    jj=0;
                    sumr=0.0;
                    while(rr>sumr)
                    {
                        jj=jj+1;
                        sumr=sumr+qqw2[jj-1];
                    }
                    qw2[i]=0.1*(jj-1);
                    
                
                
               //randomly assigns players to a district and creates edges between members of a district
                
                for(int j=0;j<N;j++)
                {
                    MM[i][j]=0;
                }
                
                ZZ[i]=0;
                
                
                
                if(i<N/2)
                {
                    
                    
                    
                    
                    Te[i]=0;
                    Vote[i]=0;
                    
                    jj=irand()%C;
                    while(Cl[0][jj]==0)
                    {
                        jj=irand()%C;
                    }
                    Ass[i]=jj;
                    if(Zr[0][jj]>0)
                    {
                        ZZ[i]=1;
                        Zr[0][jj]=Zr[0][jj]-1;
                    }
                    Cl[0][jj]=Cl[0][jj]-1;
                    
                }
                else
                {
                    Te[i]=1;
                    Vote[i]=1;
                    
                    jj=irand()%C;
                    while(Cl[1][jj]==0)
                    {
                        jj=irand()%C;
                    }
                    Ass[i]=jj;
                    if(Zr[1][jj]>0)
                    {
                        ZZ[i]=1;
                        Zr[1][jj]=Zr[1][jj]-1;
                    }
                    Cl[1][jj]=Cl[1][jj]-1;
                }
                
            }
           
            
            
            for(int i=0;i<N;i++)
            {
                for(int j=0;j<N;j++)
                {
                    if(Ass[i]==Ass[j])
                    {
                        MM[i][j]=1;
                        MM[j][i]=1;
                    }
                    
                }
            }
            
           //randomly rewires pairs of edges while retaining the party identity of the influencing node for
            
                for(int i=0;i<R;i++)
                {
                    ii1=irand()%N;
                    jj1=irand()%N;
                    
                    ii2=irand()%N;
                    jj2=irand()%N;
                    
                    
                    
                    while(MM[ii1][jj1]==0 || MM[ii2][jj2]==0 || Te[jj1]!=Te[jj2]  || ii1==jj1 || ii2==jj2 || jj1==jj2 || ii1==ii2 || ii1==jj2 || ii2==jj1 || MM[ii2][jj1]==1 || MM[ii1][jj2]==1)
                    {
                        
                        ii1=irand()%N;
                        jj1=irand()%N;
                        ii2=irand()%N;
                        jj2=irand()%N;
                        
                        
                    }
                    
                    
                   
                    
                    MM[ii1][jj1]=0;
                    MM[ii2][jj2]=0;
                    MM[ii1][jj2]=1;
                    MM[ii2][jj1]=1;
                    
                }
                
            
           
            //simulated decision dynamics
            
            for(int tt=0;tt<Tim;tt++)
            {
                
               //early game
                
                if(tt<Tth)
                {
                    
                    for(int i=0;i<N;i++)
                    {
                        //randomly choose a player to update decision
                        jj=irand()%N;
                        sumr=0.0;
                        ii1=0;
                        ii2=0;
                        
                        //calculate poll seen by that player
                        
                        for(int j=0;j<N;j++)
                        {
                            if(MM[jj][j]==1)
                            {
                                if(Te[jj]==1)
                                {
                                    sumr=sumr+Vote[j]/double(P);
                                }
                                else
                                {
                                    sumr=sumr+abs(1-Vote[j])/double(P);
                                }
                                ii1=ii1+1;
                                
                            }
                            if(MM[j][jj]==1)
                            {
                                
                                ii2=ii2+1;
                                
                            }
                            
                        }
                        
                        if(ii1!=P || ii2!=P)
                        {
                            cout<<jj<<'\t'<<i<<'\t'<<ii1<<'\t'<<ii2<<'\n';
                            exit(0);
                        }
                        
                        
                        
                        //calculate decision
                        if(sumr>=V)
                        {
                            
                            if(drand()<pw[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else if(sumr>1.0-V)
                        {
                            
                            if(drand()<qm[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else
                        {
                            if(drand()<qw[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        
                        
                        
                        
                        
                    }
                    
                }
                //late game
                else
                {
                    
                    for(int i=0;i<N;i++)
                    {
                        
                        jj=irand()%N;
                        sumr=0.0;
                        ii1=0;
                        ii2=0;
                        for(int j=0;j<N;j++)
                        {
                            if(MM[jj][j]==1)
                            {
                                if(Te[jj]==1)
                                {
                                    sumr=sumr+Vote[j]/double(P);
                                }
                                else
                                {
                                    sumr=sumr+abs(1-Vote[j])/double(P);
                                }
                                
                                ii1=ii1+1;
                                
                            }
                            if(MM[j][jj]==1)
                            {
                                
                                ii2=ii2+1;
                                
                            }
                            
                        }
                        
                        if(ii1!=P || ii2!=P)
                        {
                            cout<<jj<<'\t'<<i<<'\t'<<ii1<<'\t'<<ii2<<'\n';
                            exit(0);
                        }
                        
                        
                       
                        if(sumr>=V)
                        {
                            
                            if(drand()<pw2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else if(sumr>1.0-V)
                        {
                           
                            if(drand()<qm2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        else
                        {
                            if(drand()<qw2[jj] || ZZ[jj]==1)
                            {
                                Vote[jj]=Te[jj];
                            }
                            else
                            {
                                Vote[jj]=abs(Te[jj]-1);
                            }
                            
                        }
                        
                        
                        
                        
                    }
                    
                }
                
                
                
                
                
               
                
                
                //calculate average vote and total number of wins by each team
                if(tt==Tim-1)
                {
                    
                    for(int i=0;i<N;i++)
                    {
                        mv=mv+Vote[i]/double(T0*N);
                    }
                    
                    if(mv>=V)
                    {
                        Vcp=Vcp+1;
                    }
                    
                    if(1.0-mv>=V)
                    {
                        Vcy=Vcy+1;
                    }
                    
                    cout<<ee<<'\t'<<P<<'\t'<<N<<'\t'<<mv<<'\t'<<Vcy/double(ee+1)<<'\t'<<Vcp/double(ee+1)<<'\n';
                    
                    mv=0.0;
                    
                    
                }
                
            }
            
        }
       
    
    
    
    
    return 0;
}





