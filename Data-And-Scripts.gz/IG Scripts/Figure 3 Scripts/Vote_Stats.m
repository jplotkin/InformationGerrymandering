clear all
close all

%Note, Y and P assignments are arbitrary here


% Condition1: No asymmetry no assortment

Vote1(1:20)=[5/24 6/24 7/24 8/24 8/24 9/24 10/24 10/24 10/24 11/24 12/24 14/24 14/24 14/24 14/24 15/24 15/24 15/24 16/24 18/24];
Outcome1(1:20)=[-1 -1 -1 -1 -1 -1 0 0 0 0 0 0 0 0 0 1 1 1 1 1];

YMaj1=floor(2*Vote1-0.001);
PMaj1=1-floor(2*Vote1+0.001);

YWin1=0.5*(Outcome1+abs(Outcome1));
PWin1=0.5*(-Outcome1+abs(Outcome1));

% Condition2: No asymmetry assortment

Vote2(1:20)=[6/24 10/24 11/24 11/24 11/24 11/24 11/24 12/24 12/24 12/24 13/24 13/24 13/24 14/24 14/24 14/24 14/24 14/24 15/24 16/24];
Outcome2(1:20)=[-1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1];

YMaj2=floor(2*Vote2-0.001);
PMaj2=1-floor(2*Vote2+0.001);

YWin2=0.5*(Outcome2+abs(Outcome2));
PWin2=0.5*(-Outcome2+abs(Outcome2));

% Condition3: Info asymmetry

Vote3(1:20)=[7/24 10/24 12/24 13/24 13/24 13/24 13/24 14/24 14/24 14/24 14/24 14/24 15/24 15/24 15/24 15/24 15/24 15/24 15/24 16/24];
Outcome3(1:20)=[-1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1];

YMaj3=floor(2*Vote3-0.001);
PMaj3=1-floor(2*Vote3+0.001);

YWin3=0.5*(Outcome3+abs(Outcome3));
PWin3=0.5*(-Outcome3+abs(Outcome3));

% Condition4: No asymmetry bots

Vote4(1:20)=[11/24 11/24 11/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 13/24 13/24 13/24];
Outcome4(1:20)=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

YMaj4=floor(2*Vote4-0.001);
PMaj4=1-floor(2*Vote4+0.001);

YWin4=0.5*(Outcome4+abs(Outcome4));
PWin4=0.5*(-Outcome4+abs(Outcome4));

% Condition5: Asymmetry bots

Vote5(1:40)=[8/24 9/24 10/24 11/24 11/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 12/24 13/24 13/24 13/24 13/24 13/24 13/24 13/24 13/24 13/24 13/24 14/24 14/24 14/24 14/24 14/24 14/24 14/24 14/24 14/24 15/24 15/24 15/24 15/24 15/24];
Outcome5(1:40)=[-1 -1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1];

YMaj5=floor(2*Vote5-0.001);
PMaj5=1-floor(2*Vote5+0.001);

YWin5=0.5*(Outcome5+abs(Outcome5));
PWin5=0.5*(-Outcome5+abs(Outcome5));




disp(['Condition 3 majority (sign rank, p-value):',num2str(signrank(Vote3,0.5,'tail','right'))])



disp(['Condition 3 wins (binomial test, p-value):',num2str(myBinomTest(length(find(Outcome3==1)),length(find(abs(Outcome3)==1)),0.5,'one'))])



disp(['Condition 5 majority (sign rank, p-value):',num2str(signrank(Vote5,0.5,'tail','right'))])


disp(['Condition 5 wins (binomial test, p-value):',num2str(myBinomTest(length(find(Outcome5==1)),length(find(abs(Outcome5)==1)),0.5,'one'))])

Cond(1:20)=1;
Cond(21:40)=2;

aa(1:20,1)=abs(Outcome1);
aa(21:40,1)=abs(Outcome2);

s1=fitglm(Cond,aa,'Distribution','binomial');
disp(['Deadlock with vs without assortment (logit, p-value):',num2str(s1.Coefficients.pValue(2)/2)])


aa(1:20,1)=abs(Outcome2);
aa(21:40,1)=abs(Outcome3);

s2=fitglm(Cond,aa,'Distribution','binomial');
disp(['Deadlock with vs without assymetry (logit, p-value):', num2str(s2.Coefficients.pValue(2)/2)])


Cond(41:60)=2;
aa(1:20,1)=abs(Outcome2);
aa(21:60,1)=abs(Outcome5);

s3=fitglm(Cond,aa,'Distribution','binomial');
disp(['Deadlock with vs without asymmetric bots (logit, p-value):',num2str(s3.Coefficients.pValue(2)/2)])


xx(1,1)=sum(abs(Outcome2));
xx(2,1)=length(Outcome2)-sum(abs(Outcome2));
xx(1,2)=sum(abs(Outcome4));
xx(2,2)=length(Outcome4)-sum(abs(Outcome4));

disp(['Deadlock with vs without symmetric bots (chi square, p-value):',num2str(chisquarecont(xx))])





