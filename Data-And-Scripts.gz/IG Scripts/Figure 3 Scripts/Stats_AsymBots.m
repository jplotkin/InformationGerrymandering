clear all
close all

fid=fopen('S43_SEC_AsymBots');


i=1;

hv=zeros(1,25);


while(feof(fid)==0)
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
fscanf(fid,'%i',1);
vv(i)=fscanf(fid,'%f',1);

cv(i)=floor(vv(i)*24+0.001+1);
hv(cv(i))=hv(cv(i))+1;

fscanf(fid,'%f',1);
fscanf(fid,'%f',1);
i=i+1;
end

fclose(fid);

RR=40;
EE=10000;

for i=1:EE
    
    nv(i)=0;
   
    
    for j=1:RR
        
        
        nn=ceil(length(vv)*rand(1));
        
        if vv(nn)>=0.6 || vv(nn)<=0.4
            
            nv(i)=nv(i)+1;
            
        end
        
    end
    
end
        


g1(1)=0;
g1(2)=0;
g1(3)=0;
g1(4)=0;
g1(5)=0;
g1(6)=0;
g1(7)=0;
g1(8)=0;
g1(9)=1;
g1(10)=1;
g1(11)=1;
g1(12)=2;
g1(13)=11;
g1(14)=10;
g1(15)=9;
g1(16)=5;
g1(17)=0;
g1(18)=0;
g1(19)=0;
g1(20)=0;
g1(21)=0;
g1(22)=0;
g1(23)=0;
g1(24)=0;
g1(25)=0;;



f1(1)=g1(1);
m1r=0;

fv(1)=hv(1);
mvr=0;

for i=2:25
    
    f1(i)=g1(i)+f1(i-1);
    m1r=m1r+g1(i)*(i-1)/(24*RR);
    
    
    fv(i)=hv(i)+fv(i-1);
    mvr=mvr+hv(i)*(i-1)/(10000*24);
    
    
end

mh1=zeros(1000,1);
mhv=zeros(1000,1);

mh2=zeros(1000,1);
mh2v=zeros(1000,1);

for e=1:100000
    
    m1(e)=0;
    mv(e)=0;
    
    m2(e)=0;
    m2v(e)=0;

for j=1:RR


 ll=rand(1)*f1(25);
            
            ii=1;
            
            
            
            while ll>f1(ii)
            
                ii=ii+1;
            
            end
            
            
            m1(e)=m1(e)+(ii-1);
            
            if ii<10 || ii>15
                
                m2(e)=m2(e)+1;
                
            end
            
            
            
  ll=rand(1)*fv(25);
            
            ii=1;
            
            
            
            while ll>fv(ii)
            
                ii=ii+1;
            
            end
            
            
            mv(e)=mv(e)+(ii-1);
            
            if ii<10 || ii>15
                
                m2v(e)=m2v(e)+1;
                
            end
            
            
            
            
end

mh1(m1(e))=mh1(m1(e))+1;
mhv(mv(e))=mhv(mv(e))+1;

mh2(m2(e)+1)=mh2(m2(e)+1)+1;
mh2v(m2v(e)+1)=mh2v(m2v(e)+1)+1;

end

cnt=0;
cnt2=0;

cntv=0;
cntv2=0;


cntc=0;
cntc2=0;

cntcv=0;
cntcv2=0;

blc1=0;
buc1=0;
blcv1=0;
bucv1=0;

for i=1:1000
    
    cnt=cnt+mh1(i);
    cnt2=cnt2+mh1(1001-i);
    
    
    cntv=cntv+mhv(i);
    cntv2=cntv2+mhv(1001-i);
    
    
    
    cntc=cntc+mh2(i);
    cntc2=cntc2+mh2(1001-i);
    
    
    cntcv=cntcv+mh2v(i);
    cntcv2=cntcv2+mh2v(1001-i);
    
    if cnt<=2500
        
        bl1=(i)/(24*RR);
        
    end
    
    if cnt2<=2500
        
        bu1=(1001-i-1)/(24*RR);
        
    end
    
    
    if cntv<=2500
        
        blv1=(i)/(24*RR);
        
    end
    
    if cntv2<=2500
        
        buv1=(1001-i-1)/(24*RR);
        
    end
    
    
    
    if cntc<=2500
        
        blc1=(i-1)/RR;
        
    end
    
    if cntc2<=2500
        
        buc1=(1000-i-1)/RR;
        
    end
    
    
    if cntcv<=2500
        
        blcv1=(i-1)/RR;
        
    end
    
    if cntcv2<=2500
        
        bucv1=(1000-i-1)/RR;
        
    end
    
end

disp(['Mean vote share (experiment): ',num2str(m1r)])
disp(['Mean vote share (model): ',num2str(mvr)])
disp(['Vote share lower bound confidence (experiment): ',num2str(bl1)])
disp(['Vote share uper bound confidence (experiment): ',num2str(bu1)])
disp(['Vote share lower bound confidence (model): ',num2str(blv1)])
disp(['Vote share uper bound confidence (model): ',num2str(buv1)])

disp(['Mean consensus rate (experiment): ',num2str((sum(g1(1:10))+sum(g1(16:25)))/RR)])
disp(['Mean consensus rate (model): ',num2str(mean(m2v/RR))])
disp(['Consensus rate lower bound confidence (experiment): ',num2str(blc1)])
disp(['Consensus rate uper bound confidence (experiment): ',num2str(buc1)])
disp(['Consensus rate lower bound confidence (model): ',num2str(blcv1)])
disp(['Consensus rate uper bound confidence (model): ',num2str(bucv1)])


bar(0:1/24:1,hv./sum(hv))
hold on
bar(0:1/24:1,g1./sum(g1))   
        