clear all
close all


fid=fopen('Fig4a_Dat_Sym.txt');

i=1;

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

while(feof(fid)==0)

vd(i)=fscanf(fid,'%f',1);
vp(i)=fscanf(fid,'%f',1);
vy(i)=fscanf(fid,'%f',1);
asort(i)=fscanf(fid,'%f',1);
assy(i)=fscanf(fid,'%f',1);

i=i+1;
    
end

fclose(fid);

subplot(2,1,1);plot(assy,vd,'.');
xlabel('influence gap')
ylabel('vote skew')
title('equal size parties')

axis([-2.5 2.5 -0.6 0.6])


fid=fopen('Fig4a_Dat_Asym.txt');

i=1;

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

while(feof(fid)==0)

vd1(i)=fscanf(fid,'%f',1);
vp1(i)=fscanf(fid,'%f',1);
vy1(i)=fscanf(fid,'%f',1);
asort1(i)=fscanf(fid,'%f',1);
assy1(i)=fscanf(fid,'%f',1);

i=i+1;
    
end

fclose(fid)


subplot(2,1,2);plot(assy1,vd1,'.');
xlabel('influence gap')
ylabel('vote skew')
title('one party 2xlarger')

axis([-2.5 2.5 -0.6 0.6])