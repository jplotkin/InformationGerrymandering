clear all
close all

%Import data on bill consponsorship from FOWLER (see main text and
%SI).This contains variables:
%Number of bills - Bi
%Matrix of cosponsors for each bill - CoS
%Matrix of nomber bills cosponsored by each pair of house members - EW
%NMem number of senate members in that session - NMem

NNg(1,:)='House_093';
NNg(2,:)='House_094';
NNg(3,:)='House_095';
NNg(4,:)='House_096';
NNg(5,:)='House_097';
NNg(6,:)='House_098';
NNg(7,:)='House_099';
NNg(8,:)='House_100';
NNg(9,:)='House_101';
NNg(10,:)='House_102';
NNg(11,:)='House_103';
NNg(12,:)='House_104';
NNg(13,:)='House_105';
NNg(14,:)='House_106';
NNg(15,:)='House_107';
NNg(16,:)='House_108';
NNg(17,:)='House_109';
NNg(18,:)='House_110';

%ICPSR and Thomas identification number for each house member - PATH MUST BE SPECIFIED 


NNgH(1,:)='house_members/093_house_v2.txt';
NNgH(2,:)='house_members/094_house_v2.txt';
NNgH(3,:)='house_members/095_house_v2.txt';
NNgH(4,:)='house_members/096_house_v2.txt';
NNgH(5,:)='house_members/097_house_v2.txt';
NNgH(6,:)='house_members/098_house_v2.txt';
NNgH(7,:)='house_members/099_house_v2.txt';
NNgH(8,:)='house_members/100_house_v2.txt';
NNgH(9,:)='house_members/101_house_v2.txt';
NNgH(10,:)='house_members/102_house_v2.txt';
NNgH(11,:)='house_members/103_house_v2.txt';
NNgH(12,:)='house_members/104_house_v2.txt';
NNgH(13,:)='house_members/105_house_v2.txt';
NNgH(14,:)='house_members/106_house_v2.txt';
NNgH(15,:)='house_members/107_house_v2.txt';
NNgH(16,:)='house_members/108_house_v2.txt';
NNgH(17,:)='house_members/109_house_v2.txt';
NNgH(18,:)='house_members/110_house_v2.txt';

PartyR=zeros(length(NNg(:,1)),500);
no=zeros(length(NNg(:,1)),500);
wo=zeros(length(NNg(:,1)),500);

%Get the party of each senator from ICPSR and Thomas databases



fid=fopen('ICPSRParty.txt');

i=1;

while(feof(fid)==0)
    
PartyI(i)=fscanf(fid,'%i',1);
IDI(i)=fscanf(fid,'%i',1);

i=i+1;

end

fclose(fid);


fid=fopen('ThomasParty.txt');

i=1;

% Assign each senator to oneof the two main parties 1= Republican,
% 2=Democrat, 0=neither party

while(feof(fid)==0)
    
PartyT(i)=fscanf(fid,'%i',1);
IDT(i)=fscanf(fid,'%i',1);

i=i+1;

end

fclose(fid);

for z=1:length(NNgH(:,1))
    
fid=fopen(NNgH(z,:));
    
i=1;

while(feof(fid)==0)
    
IDRT(z,i)=fscanf(fid,'%i',1);
IDRI(z,i)=fscanf(fid,'%i',1);



if isempty(find(IDRT(z,i)==IDT))==1 || IDRT(z,i)==-1

BB=PartyI(find(IDRI(z,i)==IDI));

if BB(1)==100

PartyR(z,i)=2;

elseif BB(1)==200
   
PartyR(z,i)=1;    
    
end



else
    
BB=PartyT(find(IDRT(z,i)==IDT));

PartyR(z,i)=BB(1);

end

i=i+1;

end
   
fclose(fid);  
    
end

np=zeros(length(NNg(:,1)),500);
wp=zeros(length(NNg(:,1)),500);
nn=zeros(length(NNg(:,1)),500);
wn=zeros(length(NNg(:,1)),500);
nt=zeros(length(NNg(:,1)),500);
wt=zeros(length(NNg(:,1)),500);


kk=1;


% Calculate the number of incoming edges (weighted and unweighted) for each
% house member from each party



for z=1:length(NNg(:,1))

load(NNg(z,:));




for i=1:NMem(z)
  
    
    for j=1:NMem(z)
        
        
        
        if PartyR(z,i)==1 && PartyR(z,j)==1
    
        np(z,i)=np(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wp(z,i)=wp(z,i)+1;
            
        end
       
        
        elseif PartyR(z,i)==1 && PartyR(z,j)==2
            
        nn(z,i)=nn(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wn(z,i)=wn(z,i)+1;
            
        end
        
        
        elseif PartyR(z,i)==2 && PartyR(z,j)==1
            
        nn(z,i)=nn(z,i)+EW(i,j);
        
        
        if EW(i,j)>0
            
            wn(z,i)=wn(z,i)+1;
            
        end
        
        elseif PartyR(z,i)==2 && PartyR(z,j)==2
            
        np(z,i)=np(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wp(z,i)=wp(z,i)+1;
            
        end
        
        end
        
        nt(z,i)=nt(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wt(z,i)=wt(z,i)+1;
            
        end
        
    end
end


%Calculate the influence assortment for each house member

for i=1:NMem(z)
    
    
     
        
        if np(z,i)>=nn(z,i)
            
            no(z,i)=np(z,i)/nt(z,i);
            
        elseif np(z,i)<nn(z,i)
            
            no(z,i)=-nn(z,i)/nt(z,i);
            
        end
        
        
        if wp(z,i)>=wn(z,i)
            
            wo(z,i)=wp(z,i)/wt(z,i);
            
        elseif wp(z,i)<=wn(z,i)
            
            wo(z,i)=-wn(z,i)/wt(z,i);
            
        end
        
    
    
end

AssR(z)=mean(no(z,find(PartyR(z,:)==1 & isnan(no(z,:))==0)));
AssD(z)=mean(no(z,find(PartyR(z,:)==2 & isnan(no(z,:))==0)));



end
        

figure(1)        
plot(AssR,'ro')
hold on
plot(AssD,'bo')





%determine whether the influence assortment is different between the two
%parties in each session
        



for z=1:length(NNg(:,1))
    
  [h, p, ci, stats]=ttest2(no(z,find(PartyR(z,:)==1 & isnan(no(z,:))==0)),no(z,find(PartyR(z,:)==2 & isnan(no(z,:))==0)));
  pp(z,1)=p;
  tt(z,1)=stats.tstat;
  ddf(z,1)=stats.df;
  
 
  
end
        
        

    
    
    
    
    
    
    
    
    
