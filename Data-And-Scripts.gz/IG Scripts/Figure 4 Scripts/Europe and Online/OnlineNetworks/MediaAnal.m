clear all
close all

load 'MediaLinks'


np=zeros(1,max(Ref));
wp=zeros(1,max(Ref));
nn=zeros(1,max(Ref));
wn=zeros(1,max(Ref));
nt=zeros(1,max(Ref));
wt=zeros(1,max(Ref));
Sco=zeros(1,max(Ref));
no=zeros(1,max(Ref));



for i=1:length(Source)
    
     if isempty(find(Ref(i)==ID))==0 
    
    Sco(Ref(i))=Sc(find(Ref(i)==ID));
    
     end
    
    if isempty(find(Ref(i)==ID))==0 && isempty(find(Source(i)==ID))==0
    
   if Sc(find(Ref(i)==ID))<0.0 && Sc(find(Source(i)==ID))<0.0
       
       np(Ref(i))=np(Ref(i))+1;
       wp(Ref(i))=wp(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       nt(Ref(i))=nt(Ref(i))+1;
       wt(Ref(i))=wt(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       
   elseif Sc(find(Ref(i)==ID))<0.0 && Sc(find(Source(i)==ID))>0.0
       
       
       nn(Ref(i))=nn(Ref(i))+1;
       wn(Ref(i))=wn(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       nt(Ref(i))=nt(Ref(i))+1;
       wt(Ref(i))=wt(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       
       
   elseif Sc(find(Ref(i)==ID))>0.0 && Sc(find(Source(i)==ID))>0.0
       
       np(Ref(i))=np(Ref(i))+1;
       wp(Ref(i))=wp(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       nt(Ref(i))=nt(Ref(i))+1;
       wt(Ref(i))=wt(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       
   elseif Sc(find(Ref(i)==ID))>0.0 && Sc(find(Source(i)==ID))<0.0
       
       
       nn(Ref(i))=nn(Ref(i))+1;
       wn(Ref(i))=wn(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       nt(Ref(i))=nt(Ref(i))+1;
       wt(Ref(i))=wt(Ref(i))+IDE(i);%*abs(Sc(find(Source(i)==ID)));
       
   end
   
    end
   
   
end

for i=1:max(Ref)
    
    
        
        if np(i)>nn(i)
            
            no(i)=np(i)/nt(i);
            
        elseif np(i)<=nn(i)
            
            no(i)=-nn(i)/nt(i);
            
        end
        
        
        if wp(i)>wn(i)
            
            wo(i)=wp(i)/wt(i);
            
        elseif wp(i)<=wn(i)
            
            wo(i)=-wn(i)/wt(i);
            
        end
    
    
    
end
    

Asym=mean(wo(find(Sco>0 & isnan(wo)==0)))-mean(wo(find(Sco<0 & isnan(wo)==0)));
Assort=mean(wo(find(isnan(no)==0)));

[h, p, ci, stats]=ttest2(wo(find(Sco>0 & isnan(wo)==0)),wo(find(Sco<0 & isnan(wo)==0)));
tt=stats.tstat;
ddf=stats.df;

       