clear all
close all


load 2010Twitter

n=2;

for i=1:length(ID)
        
    
        if Pol(ID(i))~=0
        
        np(i)=length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))==Pol(ID(i))))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
        nn(i)=length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))==-Pol(ID(i))))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
        
        else
            
        np(i)=length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))==0))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
        nn(i)=length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))~=0))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
        
        end
        
        Ou(i)=length(find(Sou==(ID(i)) & ETyp==n));
        Inn(i)=length(find(Tar==(ID(i)) & ETyp==n));
        
        
        
        if np(i)>nn(i)
            
            no(i)=length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))==Pol(ID(i))))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
            
        elseif np(i)<nn(i)
            
            no(i)=-length(find(Pol(Tar(find(Sou==(ID(i)) & ETyp==n)))==-Pol(ID(i))))/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
            
        else
            
            no(i)=0/length(Tar(find(Sou==(ID(i)) & ETyp==n)));
            
        end
        
end

Asym=mean(no(find(Pol==1 & isnan(no)==0)))-mean(no(find(Pol==-1 & isnan(no)==0)));
Assort=mean(no(find(isnan(no)==0)));

[h, p, ci, stats]=ttest2(no(find(Pol==1 & isnan(no)==0)),no(find(Pol==-1 & isnan(no)==0)));
tt=stats.tstat;
ddf=stats.df;