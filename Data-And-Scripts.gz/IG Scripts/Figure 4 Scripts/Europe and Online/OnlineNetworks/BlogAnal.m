clear all
close all


load BlogLinks

n=1;

for i=1:length(Pol)
        
    
        
        
        np(i)=length(find(Pol(Tar(find(Sou==(i))))==Pol(i)))/length(Tar(find(Sou==(i))));
        nn(i)=length(find(Pol(Tar(find(Sou==(i))))==-Pol(i)))/length(Tar(find(Sou==(i))));
        
        
        
        Ou(i)=length(find(Sou==(i)));
        Inn(i)=length(find(Tar==(i)));
        
        
        
        if np(i)>nn(i)
            
            no(i)=length(find(Pol(Tar(find(Sou==(i))))==Pol(i)))/length(Tar(find(Sou==(i))));
            
        elseif np(i)<nn(i)
            
            no(i)=-length(find(Pol(Tar(find(Sou==(i))))==-Pol(i)))/length(Tar(find(Sou==(i))));
            
        else
            
            no(i)=0/length(Tar(find(Sou==(i))));
            
        end
        
end

Asym=mean(no(find(Pol==1 & isnan(no)==0)))-mean(no(find(Pol==-1 & isnan(no)==0)));
Assort=mean(no(find(isnan(no)==0)));

[h, p, ci, stats]=ttest2(no(find(Pol==1 & isnan(no)==0)),no(find(Pol==-1 & isnan(no)==0)));
tt=stats.tstat;
ddf=stats.df;