clear all
close all

fid=fopen('France-2012-IDL.txt');

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

i=1;

while(feof(fid)==0)
kk(i)=fscanf(fid,'%i',1);
Id(kk(i))=fscanf(fid,'%s',1);
NS(kk(i))=fscanf(fid,'%i',1);
i=i+1;
end


fid=fopen('France-2012-EdgeL.txt');

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

wp=zeros(1,max(kk));
wn=zeros(1,max(kk));
wt=zeros(1,max(kk));

Par='G';

while(feof(fid)==0)
jj=fscanf(fid,'%i',1);
ii=fscanf(fid,'%i',1);
W=fscanf(fid,'%i',1);

if Id(jj)==Par && Id(ii)==Par
    
    wp(ii)=wp(ii)+W;
    wp(jj)=wp(jj)+W;
    
elseif Id(jj)==Par && Id(ii)~=Par
    
     wn(ii)=wn(ii)+W;
     wn(jj)=wn(jj)+W;
     
elseif Id(jj)~=Par && Id(ii)~=Par
    
    wp(ii)=wp(ii)+W;
    wp(jj)=wp(jj)+W;
    
elseif Id(jj)~=Par && Id(ii)==Par
    
    wn(ii)=wn(ii)+W;
    wn(jj)=wn(jj)+W;
    
end

wt(ii)=wt(ii)+W;
wt(jj)=wt(jj)+W;

end
    
    
    
for i=1:max(kk)
    
    if wp(i)>wn(i)
        
        wo(i)=wp(i)/wt(i);
        
    else
        
        wo(i)=-wn(i)/wt(i);
        
    end
    
end

AsymL=mean(wo(find(Id=='G' & isnan(wo)==0)))-mean(wo(find(Id~='G' & isnan(wo)==0)));
AssortL=mean(wo(find(isnan(wo)==0)));

[h, pL, ci, stats]=ttest2(wo(find(Id=='G' & isnan(wo)==0)),wo(find(Id~='G' & isnan(wo)==0)));
ttL=stats.tstat;
ddfL=stats.df;

clear kk Id ND wo;

fid=fopen('France-2012-IDU.txt');

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

i=1;

while(feof(fid)==0)
kk(i)=fscanf(fid,'%i',1);
Id(kk(i))=fscanf(fid,'%s',1);
NS(kk(i))=fscanf(fid,'%i',1);
i=i+1;
end


fid=fopen('France-2012-EdgeU.txt');

fscanf(fid,'%s',1);
fscanf(fid,'%s',1);
fscanf(fid,'%s',1);

wp=zeros(1,max(kk));
wn=zeros(1,max(kk));
wt=zeros(1,max(kk));

Par='G';

while(feof(fid)==0)
jj=fscanf(fid,'%i',1);
ii=fscanf(fid,'%i',1);
W=fscanf(fid,'%i',1);

if Id(jj)==Par && Id(ii)==Par
    
    wp(ii)=wp(ii)+W;
    wp(jj)=wp(jj)+W;
    
elseif Id(jj)==Par && Id(ii)~=Par
    
     wn(ii)=wn(ii)+W;
     wn(jj)=wn(jj)+W;
     
elseif Id(jj)~=Par && Id(ii)~=Par
    
    wp(ii)=wp(ii)+W;
    wp(jj)=wp(jj)+W;
    
elseif Id(jj)~=Par && Id(ii)==Par
    
    wn(ii)=wn(ii)+W;
    wn(jj)=wn(jj)+W;
    
end

wt(ii)=wt(ii)+W;
wt(jj)=wt(jj)+W;

end
    
    
    
for i=1:max(kk)
    
    if wp(i)>wn(i)
        
        wo(i)=wp(i)/wt(i);
        
    else
        
        wo(i)=-wn(i)/wt(i);
        
    end
    
end




AsymU=mean(wo(find(Id=='G' & isnan(wo)==0)))-mean(wo(find(Id~='G' & isnan(wo)==0)));
AssortU=mean(wo(find(isnan(wo)==0)));

[h, pU, ci, stats]=ttest2(wo(find(Id=='G' & isnan(wo)==0)),wo(find(Id~='G' & isnan(wo)==0)));
ttU=stats.tstat;
ddfU=stats.df;


%C=Conservatives
%S=Socialists
%E=Ecologists
%R=Centrists
%L=Communists
%A=Radicals
%I=Independents