clear all
close all

%France Lower

LegA(1)=0.7826;
LegI(1)=0.4029;

%Czech Lower

LegA(2)=0.7093;
LegI(2)=0.1924;

%Italy Lower

LegA(3)=0.8752;
LegI(3)=0.1114;

%Romania Lower

LegA(4)=0.5344;
LegI(4)=0.4487;

%France Upper

UpA(1)=0.9601;
UpI(1)=0.0025;

%Czech Upper

UpA(2)=0.5917;
UpI(2)=0.0632;

%Italy Upper

UpA(3)=0.7084;
UpI(3)=0.4121;

%Romania Upper

UpA(4)=0.5668;
UpI(4)=0.6398;

% Political blog links

SoA(1)=0.8469;
SoI(1)=0.1001;

% Media consumption

SoA(2)=0.5659;
SoI(2)=0.1496;

% Political Twitter

SoA(3)=0.2369;
SoI(3)=0.2477;

plot(LegA,LegI,'o');
hold on
plot(UpA,UpI,'o');
plot(SoA,SoI,'o');
