clear all
close all

%Import data on bill consponsorship from FOWLER (see main text and
%SI).This contains variables:
%Number of bills - Bi
%Matrix of cosponsors for each bill - CoS
%Matrix of nomber bills cosponsored by each pair of senators - EW
%NMem number of senate members in that session - NMem

NNg(1,:)='Senate_093';
NNg(2,:)='Senate_094';
NNg(3,:)='Senate_095';
NNg(4,:)='Senate_096';
NNg(5,:)='Senate_097';
NNg(6,:)='Senate_098';
NNg(7,:)='Senate_099';
NNg(8,:)='Senate_100';
NNg(9,:)='Senate_101';
NNg(10,:)='Senate_102';
NNg(11,:)='Senate_103';
NNg(12,:)='Senate_104';
NNg(13,:)='Senate_105';
NNg(14,:)='Senate_106';
NNg(15,:)='Senate_107';
NNg(16,:)='Senate_108';
NNg(17,:)='Senate_109';
NNg(18,:)='Senate_110';

%ICPSR and Thomas identification number for each senator - PATH MUST BE SPECIFIED

NNgH(1,:)='senate_members/093_senators_v2.txt';
NNgH(2,:)='senate_members/094_senators_v2.txt';
NNgH(3,:)='senate_members/095_senators_v2.txt';
NNgH(4,:)='senate_members/096_senators_v2.txt';
NNgH(5,:)='senate_members/097_senators_v2.txt';
NNgH(6,:)='senate_members/098_senators_v2.txt';
NNgH(7,:)='senate_members/099_senators_v2.txt';
NNgH(8,:)='senate_members/100_senators_v2.txt';
NNgH(9,:)='senate_members/101_senators_v2.txt';
NNgH(10,:)='senate_members/102_senators_v2.txt';
NNgH(11,:)='senate_members/103_senators_v2.txt';
NNgH(12,:)='senate_members/104_senators_v2.txt';
NNgH(13,:)='senate_members/105_senators_v2.txt';
NNgH(14,:)='senate_members/106_senators_v2.txt';
NNgH(15,:)='senate_members/107_senators_v2.txt';
NNgH(16,:)='senate_members/108_senators_v2.txt';
NNgH(17,:)='senate_members/109_senators_v2.txt';
NNgH(18,:)='senate_members/110_senators_v2.txt';

PartyR=zeros(length(NNg(:,1)),110);
no=zeros(length(NNg(:,1)),110);
wo=zeros(length(NNg(:,1)),110);

%Get the party of each senator from ICPSR and Thomas databases


fid=fopen('ICPSRParty.txt');

i=1;

while(feof(fid)==0)
    
PartyI(i)=fscanf(fid,'%i',1);
IDI(i)=fscanf(fid,'%i',1);

i=i+1;

end

fclose(fid);


fid=fopen('ThomasParty.txt');

i=1;

while(feof(fid)==0)
    
PartyT(i)=fscanf(fid,'%i',1);
IDT(i)=fscanf(fid,'%i',1);

i=i+1;

end

fclose(fid);


% Assign each senator to oneof the two main parties 1= Republican,
% 2=Democrat, 0=neither party

for z=1:length(NNgH(:,1))
    
fid=fopen(NNgH(z,:));
    
i=1;

while(feof(fid)==0)
    
IDRT(z,i)=fscanf(fid,'%i',1);
IDRI(z,i)=fscanf(fid,'%i',1);



if isempty(find(IDRT(z,i)==IDT))==1 || IDRT(z,i)==-1

BB=PartyI(find(IDRI(z,i)==IDI));

if BB(1)==100

PartyR(z,i)=2;

elseif BB(1)==200
   
PartyR(z,i)=1;    
    
end



else
    
BB=PartyT(find(IDRT(z,i)==IDT));

PartyR(z,i)=BB(1);

end

i=i+1;

end
   
fclose(fid);  
    
end



np=zeros(length(NNg(:,1)),110);
wp=zeros(length(NNg(:,1)),110);
nn=zeros(length(NNg(:,1)),110);
wn=zeros(length(NNg(:,1)),110);
nt=zeros(length(NNg(:,1)),110);
wt=zeros(length(NNg(:,1)),110);

kk=1;

%Party controlling senate in each session

Cntr(1:4)=2;
Cntr(5:7)=1;
Cntr(8:11)=2;
Cntr(12:14)=1;
Cntr(15:16)=2;
Cntr(17)=1;
Cntr(18)=2;

% Calculate the number of incoming edges (weighted and unweighted) for each
% senator from each party

for z=1:length(NNg(:,1))

load(NNg(z,:));




for i=1:NMem(z)
    for j=1:NMem(z)
        
        
        
        if PartyR(z,i)==1 && PartyR(z,j)==1
    
        np(z,i)=np(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wp(z,i)=wp(z,i)+1;
            
        end
       
        
        elseif PartyR(z,i)==1 && PartyR(z,j)==2
            
        nn(z,i)=nn(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wn(z,i)=wn(z,i)+1;
            
        end
        
        
        elseif PartyR(z,i)==2 && PartyR(z,j)==1
            
        nn(z,i)=nn(z,i)+EW(i,j);
        
        
        if EW(i,j)>0
            
            wn(z,i)=wn(z,i)+1;
            
        end
        
        elseif PartyR(z,i)==2 && PartyR(z,j)==2
            
        np(z,i)=np(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wp(z,i)=wp(z,i)+1;
            
        end
        
        end
        
        nt(z,i)=nt(z,i)+EW(i,j);
        
        if EW(i,j)>0
            
            wt(z,i)=wt(z,i)+1;
            
        end
        
    end
end

%Calculate the influence assortment for each senator

for i=1:NMem(z)
    
    
        
        if np(z,i)>=nn(z,i)
            
            no(z,i)=np(z,i)/nt(z,i);
            
        elseif np(z,i)<nn(z,i)
            
            no(z,i)=-nn(z,i)/nt(z,i);
            
        end
        
        
        if wp(z,i)>=wn(z,i)
            
            wo(z,i)=wp(z,i)/wt(z,i);
            
        elseif wp(z,i)<wn(z,i)
            
            wo(z,i)=-wn(z,i)/wt(z,i);
            
        end
        
       
    
    
end

% calculate the influence assortment for each party

AssR(z)=mean(no(z,find(PartyR(z,:)==1 & isnan(no(z,:))==0)));
AssD(z)=mean(no(z,find(PartyR(z,:)==2 & isnan(no(z,:))==0)));



end
        
figure(1)        
plot(AssR,'ro')
hold on
plot(AssD,'bo')





%determine whether the influence assortment is different between the two
%parties in each session
        
        
for z=1:length(NNg(:,1))
    
  [h, p, ci, stats]=ttest2(no(z,find(PartyR(z,:)==1 & isnan(no(z,:))==0)),no(z,find(PartyR(z,:)==2 & isnan(no(z,:))==0)));
  pp(z,1)=p;
  tt(z,1)=stats.tstat;
  ddf(z,1)=stats.df;
  
  
end
        

    
    
    
    
    
    
    
    
    
